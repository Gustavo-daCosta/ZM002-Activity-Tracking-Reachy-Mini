from __future__ import annotations

import argparse
import csv
import gc
import json
import os
import socket
import statistics
import threading
import time
from dataclasses import asdict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import cv2
import psutil

from benchmark import Result, percentile
from gpu_models import create_gpu_models


ALIASES = {
    "blazepose": "BlazePose-GPU",
    "gpu": "BlazePose-GPU",
}


POSE_CONNECTIONS = [
    (11, 12), (11, 13), (13, 15),
    (12, 14), (14, 16),
    (11, 23), (12, 24), (23, 24),
    (23, 25), (25, 27),
    (24, 26), (26, 28),
    (27, 29), (29, 31),
    (28, 30), (30, 32),
]


class LiveFrame:
    def __init__(self):
        self.lock = threading.Lock()
        self.jpeg = None
        self.running = True

    def set(self, frame):
        ok, encoded = cv2.imencode(
            ".jpg",
            frame,
            [cv2.IMWRITE_JPEG_QUALITY, 80],
        )
        if ok:
            with self.lock:
                self.jpeg = encoded.tobytes()

    def get(self):
        with self.lock:
            return self.jpeg


class FeedHandler(BaseHTTPRequestHandler):
    frame_store = None

    def log_message(self, fmt, *args):
        return

    def do_GET(self):
        if self.path == "/":
            html = """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reachy Mini Model Benchmark</title>
<style>
body{margin:0;background:#111;color:#eee;font-family:Arial,sans-serif;text-align:center}
h2{margin:14px}
img{max-width:96vw;max-height:88vh;border:1px solid #444}
</style>
</head>
<body>
<h2>Reachy Mini — live model benchmark</h2>
<img src="/stream">
</body>
</html>
"""
            data = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path != "/stream":
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header(
            "Content-Type",
            "multipart/x-mixed-replace; boundary=frame",
        )
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Pragma", "no-cache")
        self.end_headers()

        last = None

        try:
            while self.frame_store.running:
                jpeg = self.frame_store.get()

                if jpeg is None or jpeg == last:
                    time.sleep(0.02)
                    continue

                last = jpeg

                self.wfile.write(b"--frame\r\n")
                self.wfile.write(
                    b"Content-Type: image/jpeg\r\n"
                )
                self.wfile.write(
                    f"Content-Length: {len(jpeg)}\r\n\r\n".encode()
                )
                self.wfile.write(jpeg)
                self.wfile.write(b"\r\n")
                self.wfile.flush()

        except (BrokenPipeError, ConnectionResetError):
            pass


def start_server(frame_store, port):
    FeedHandler.frame_store = frame_store

    server = ThreadingHTTPServer(
        ("0.0.0.0", port),
        FeedHandler,
    )

    thread = threading.Thread(
        target=server.serve_forever,
        daemon=True,
    )
    thread.start()

    return server


def local_ip():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        address = sock.getsockname()[0]
        sock.close()
        return address
    except Exception:
        return "REACHY_IP"


def select_models(spec):
    models = create_gpu_models()

    if spec.lower() == "all":
        return models

    wanted = set()

    for item in spec.split(","):
        key = item.strip().lower()

        if key not in ALIASES:
            raise SystemExit(
                f"Unknown model '{item}'. "
                f"Use: {', '.join(ALIASES)} or all."
            )

        wanted.add(ALIASES[key])

    selected = [
        model
        for model in models
        if model.name in wanted
    ]

    if not selected:
        raise SystemExit("No models selected.")

    return selected


def draw_blazepose(frame, data):
    try:
        landmarks = data.pose_landmarks[0]
    except Exception:
        return

    h, w = frame.shape[:2]
    points = []

    for lm in landmarks:
        x = int(lm.x * w)
        y = int(lm.y * h)
        points.append((x, y))

        if 0 <= x < w and 0 <= y < h:
            cv2.circle(
                frame,
                (x, y),
                4,
                (0, 255, 0),
                -1,
            )

    for a, b in POSE_CONNECTIONS:
        if a < len(points) and b < len(points):
            cv2.line(
                frame,
                points[a],
                points[b],
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )


def extract_keypoints(obj):
    import numpy as np

    if isinstance(obj, dict):
        for key in ("keypoints", "keypoints_xy"):
            if key in obj:
                try:
                    arr = np.asarray(obj[key])
                    if arr.ndim == 3:
                        arr = arr[0]
                    if arr.ndim == 2 and arr.shape[1] >= 2:
                        return arr
                except Exception:
                    pass

        for value in obj.values():
            found = extract_keypoints(value)
            if found is not None:
                return found

    elif isinstance(obj, (list, tuple)):
        for value in obj:
            found = extract_keypoints(value)
            if found is not None:
                return found

    return None


def draw_vitpose(frame, data):
    keypoints = extract_keypoints(data)

    if keypoints is None:
        return

    h, w = frame.shape[:2]

    for point in keypoints:
        x = int(float(point[0]))
        y = int(float(point[1]))

        if 0 <= x < w and 0 <= y < h:
            cv2.circle(
                frame,
                (x, y),
                4,
                (0, 255, 0),
                -1,
            )


def top_class_info(data):
    try:
        import torch

        if not torch.is_tensor(data):
            return None

        values = data.detach().float().flatten()

        if values.numel() == 0:
            return None

        index = int(values.argmax().item())
        score = float(values[index].item())

        return index, score

    except Exception:
        return None


def annotate(
    frame,
    model,
    output,
    latency_ms,
    camera_fps,
    model_fps,
):
    data = (
        output.value
        if output is not None
        else None
    )

    if model.name == "BlazePose" and data is not None:
        draw_blazepose(frame, data)

    elif model.name == "ViTPose" and data is not None:
        draw_vitpose(frame, data)

    elif model.name in {
        "MoViNet-A0",
        "TSM-MobileNetV2",
    }:
        info = top_class_info(data)

        if info is not None:
            index, score = info

            cv2.putText(
                frame,
                f"Top class index: {index}  score: {score:.3f}",
                (15, 92),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )

    lines = [
        f"Model: {model.name}",
        "Device: REACHY MINI integrated GPU (LiteRT WebGPU)",
        f"Camera FPS: {camera_fps:.1f}",
        f"Model FPS: {model_fps:.1f}",
        f"Inference: {latency_ms:.1f} ms",
    ]

    y = 30

    for line in lines:
        cv2.putText(
            frame,
            line,
            (15, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (0, 255, 0),
            2,
            cv2.LINE_AA,
        )
        y += 30


def benchmark_one(
    model,
    mini,
    feed,
    duration,
    warmup_frames,
    port,
):
    process = psutil.Process(os.getpid())

    result = Result(
        model=model.name,
        family=model.family,
        task=model.task,
        input_type=model.input_type,
        implementation=model.implementation,
        device_requested="gpu",
        device_used="GPU/WebGPU",
    )

    try:
        print()
        print("=" * 110)
        print(f"MODEL: {model.name}")
        print("=" * 110)
        print("Inference device: Reachy Mini integrated GPU (LiteRT WebGPU)")
        print(f"Live feed: http://reachy-mini.local:{port}/")
        print()

        before_load = (
            process.memory_info().rss / 1024**2
        )

        load_start = time.perf_counter()

        model._device_used = "gpu"
        model.load("gpu")
        model.synchronize()

        result.load_ms = (
            time.perf_counter() - load_start
        ) * 1000.0

        result.device_used = model.device_used()
        result.ram_after_load_mb = (
            process.memory_info().rss / 1024**2
        )

        try:
            result.parameters = model.parameter_count()
        except Exception:
            pass

        try:
            result.model_size_mb = model.model_size_mb()
        except Exception:
            pass

        print(f"Load time: {result.load_ms:.2f} ms")
        print(f"Actual device: {result.device_used}")
        print(f"Parameters: {result.parameters or '-'}")

        # Camera warmup.
        model.reset()

        warmup_count = 0
        while warmup_count < warmup_frames:
            frame = mini.media.get_frame()

            if frame is None:
                continue

            model.process_frame(
                frame,
                warmup_count,
                10.0,
            )
            warmup_count += 1

        model.synchronize()
        model.reset()

        latencies = []
        cpu_samples = []
        peak_ram_delta = 0.0

        frames_seen = 0
        errors = 0

        start = time.perf_counter()
        camera_window_start = start
        camera_window_frames = 0
        camera_fps = 0.0

        print()
        print(
            "LIVE FEED ACTIVE. Open the URL above on your laptop."
        )
        print(
            "The model itself is running on the Reachy Mini integrated GPU."
        )
        print()

        while time.perf_counter() - start < duration:
            frame = mini.media.get_frame()

            if frame is None:
                continue

            frame_index = frames_seen
            frames_seen += 1
            camera_window_frames += 1

            now = time.perf_counter()
            camera_elapsed = (
                now - camera_window_start
            )

            if camera_elapsed >= 1.0:
                camera_fps = (
                    camera_window_frames
                    / camera_elapsed
                )
                camera_window_frames = 0
                camera_window_start = now

            try:
                model.synchronize()

                t0 = time.perf_counter()

                output = model.process_frame(
                    frame,
                    frame_index,
                    camera_fps or 10.0,
                )

                model.synchronize()

                latency_ms = (
                    time.perf_counter() - t0
                ) * 1000.0

                completed = (
                    output is not None
                    and getattr(
                        output,
                        "value",
                        None,
                    ) is not None
                )

                if completed:
                    latencies.append(
                        latency_ms
                    )

                rss = (
                    process.memory_info().rss
                    / 1024**2
                )

                peak_ram_delta = max(
                    peak_ram_delta,
                    rss - result.ram_after_load_mb,
                )

                model_fps = (
                    len(latencies)
                    / max(
                        time.perf_counter() - start,
                        0.001,
                    )
                )

                annotate(
                    frame,
                    model,
                    output,
                    latency_ms,
                    camera_fps,
                    model_fps,
                )

                # JPEG encoding is deliberately outside the
                # model timing section.
                feed.set(frame)

                if frames_seen % 20 == 0:
                    cpu_samples.append(
                        process.cpu_percent(0.05)
                    )

            except Exception as exc:
                errors += 1

                if errors <= 5:
                    print(
                        f"\nFrame {frame_index} error: "
                        f"{type(exc).__name__}: {exc}"
                    )

        measured_s = time.perf_counter() - start

        result.frames_seen = frames_seen
        result.successful_inferences = len(latencies)
        result.errors = errors
        result.video_fps = camera_fps
        result.video_frames = frames_seen
        result.video_duration_s = measured_s
        result.peak_ram_delta_mb = peak_ram_delta

        result.avg_process_cpu_percent = (
            statistics.mean(cpu_samples)
            if cpu_samples
            else 0.0
        )

        if latencies:
            result.avg_ms = statistics.mean(latencies)
            result.p50_ms = percentile(latencies, 50)
            result.p95_ms = percentile(latencies, 95)
            result.p99_ms = percentile(latencies, 99)
            result.min_ms = min(latencies)
            result.max_ms = max(latencies)
            result.total_inference_s = (
                sum(latencies) / 1000.0
            )
            result.output_fps = (
                len(latencies) / measured_s
            )

        else:
            result.status = "ERROR"
            result.error = (
                "No completed model inferences."
            )

        print()
        print(f"Camera FPS      : {result.video_fps:.2f}")
        print(f"Frames received : {result.frames_seen}")
        print(f"Completed       : {result.successful_inferences}")
        print(f"Average latency : {result.avg_ms:.2f} ms")
        print(f"P50             : {result.p50_ms:.2f} ms")
        print(f"P95             : {result.p95_ms:.2f} ms")
        print(f"P99             : {result.p99_ms:.2f} ms")
        print(f"Min / Max       : {result.min_ms:.2f} / {result.max_ms:.2f} ms")
        print(f"Model FPS       : {result.output_fps:.2f}")
        print(f"CPU             : {result.avg_process_cpu_percent:.1f}%")
        print(f"RAM delta       : {result.peak_ram_delta_mb:.1f} MB")

        return result

    except Exception as exc:
        result.status = "ERROR"
        result.error = f"{type(exc).__name__}: {exc}"
        print(f"ERROR: {result.error}")
        return result

    finally:
        try:
            model.close()
        except Exception:
            pass

        gc.collect()


def save_results(results):
    Path("results").mkdir(exist_ok=True)

    timestamp = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    json_path = (
        Path("results")
        / f"reachy_camera_{timestamp}.json"
    )

    csv_path = (
        Path("results")
        / f"reachy_camera_{timestamp}.csv"
    )

    payload = [
        asdict(result)
        for result in results
    ]

    json_path.write_text(
        json.dumps(
            payload,
            indent=2,
        ),
        encoding="utf-8",
    )

    if payload:
        with csv_path.open(
            "w",
            newline="",
            encoding="utf-8",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=payload[0].keys(),
            )
            writer.writeheader()
            writer.writerows(payload)

    return json_path, csv_path


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Reachy Mini onboard live-camera model benchmark."
        )
    )

    parser.add_argument(
        "--models",
        default="all",
        help="all or comma-separated model names",
    )

    parser.add_argument(
        "--duration",
        type=float,
        default=30.0,
        help="Seconds per model.",
    )

    parser.add_argument(
        "--warmup",
        type=int,
        default=10,
        help="Real camera frames for warmup.",
    )

    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="HTTP live-feed port.",
    )

    args = parser.parse_args()

    models = select_models(
        args.models
    )

    try:
        from reachy_mini import ReachyMini
    except ImportError as exc:
        raise SystemExit(
            "reachy_mini is not installed in this environment."
        ) from exc

    feed = LiveFrame()
    server = start_server(
        feed,
        args.port,
    )

    print("=" * 110)
    print("REACHY MINI GPU MODEL BENCHMARK")
    print("=" * 110)
    print("IMPORTANT: model inference runs on the Reachy Mini CPU.")
    print()
    print(
        f"On robot : http://localhost:{args.port}/"
    )
    print(
        f"From PC  : http://reachy-mini.local:{args.port}/"
    )
    print(
        f"IP       : http://{local_ip()}:{args.port}/"
    )
    print()
    print(
        "Open the From PC or IP URL in your browser to see "
        "the annotated camera feed."
    )
    print()

    results = []

    try:
        # default auto-selects the local media backend when the
        # application runs on the same machine as the daemon.
        with ReachyMini(
            media_backend="default"
        ) as mini:

            for model in models:
                result = benchmark_one(
                    model,
                    mini,
                    feed,
                    args.duration,
                    args.warmup,
                    args.port,
                )
                results.append(result)

    finally:
        feed.running = False
        server.shutdown()
        server.server_close()

    json_path, csv_path = save_results(
        results
    )

    print()
    print("=" * 120)
    print("FINAL REACHY MINI RESULTS")
    print("=" * 120)

    print(
        f"{'Model':<22}"
        f"{'Status':<9}"
        f"{'Avg ms':>10}"
        f"{'P95':>10}"
        f"{'FPS':>10}"
        f"{'Camera':>10}"
        f"{'CPU':>9}"
        f"{'RAM Δ':>10}"
    )

    print("-" * 120)

    for result in results:
        print(
            f"{result.model:<22}"
            f"{result.status:<9}"
            f"{result.avg_ms:>10.2f}"
            f"{result.p95_ms:>10.2f}"
            f"{result.output_fps:>10.2f}"
            f"{result.video_fps:>10.2f}"
            f"{result.avg_process_cpu_percent:>8.1f}%"
            f"{result.peak_ram_delta_mb:>9.1f}M"
        )

    print()
    print(f"JSON: {json_path}")
    print(f"CSV : {csv_path}")


if __name__ == "__main__":
    main()
