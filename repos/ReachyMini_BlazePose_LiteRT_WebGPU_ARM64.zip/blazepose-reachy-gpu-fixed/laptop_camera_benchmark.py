from __future__ import annotations

import argparse
import csv
import gc
import json
import os
import platform
import statistics
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

import cv2
import psutil

from benchmark import Result, fmt, percentile
from models import create_models


ALIASES = {
    "blazepose": "BlazePose",
    "movinet": "MoViNet-A0",
    "tsm": "TSM-MobileNetV2",
    "vitpose": "ViTPose",
}


# MediaPipe BlazePose in this project is CPU-only.
# PyTorch models use the requested CPU/CUDA device.
def requested_device_for(model, requested: str) -> str:
    if getattr(model, "always_cpu", False):
        return "cpu"
    return requested


def select_models(spec: str):
    models = create_models()

    if spec.lower() == "all":
        return models

    wanted = set()
    for item in spec.split(","):
        key = item.strip().lower()
        if key not in ALIASES:
            raise SystemExit(
                f"Unknown model '{item}'. "
                f"Use: {', '.join(ALIASES)} or all."
            )
        wanted.add(ALIASES[key])

    selected = [m for m in models if m.name in wanted]

    if not selected:
        raise SystemExit("No models selected.")

    return selected


def open_camera(index: int, width: int | None, height: int | None):
    # DirectShow first on Windows; fallback for other backends.
    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap.release()
        cap = cv2.VideoCapture(index)

    if not cap.isOpened():
        raise RuntimeError(
            f"Could not open laptop camera index {index}."
        )

    if width:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    if height:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

    return cap


POSE_CONNECTIONS = [
    (11, 12), (11, 13), (13, 15),
    (12, 14), (14, 16),
    (11, 23), (12, 24), (23, 24),
    (23, 25), (25, 27),
    (24, 26), (26, 28),
    (27, 29), (29, 31),
    (28, 30), (30, 32),
]


def draw_blazepose(frame, data):
    try:
        landmarks = data.pose_landmarks[0]
    except Exception:
        return

    h, w = frame.shape[:2]
    points = []

    for lm in landmarks:
        x = int(lm.x * w)
        y = int(lm.y * h)
        points.append((x, y))

        if 0 <= x < w and 0 <= y < h:
            cv2.circle(frame, (x, y), 4, (0, 255, 0), -1)

    for a, b in POSE_CONNECTIONS:
        if a < len(points) and b < len(points):
            cv2.line(
                frame,
                points[a],
                points[b],
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )


def _extract_keypoints(obj):
    """
    Recursively find common ViTPose keypoint structures.
    Returns an Nx2 numpy-like array or None.
    """
    import numpy as np

    if isinstance(obj, dict):
        for key in ("keypoints", "keypoints_xy"):
            if key in obj:
                try:
                    arr = np.asarray(obj[key])
                    if arr.ndim == 3:
                        arr = arr[0]
                    if arr.ndim == 2 and arr.shape[1] >= 2:
                        return arr
                except Exception:
                    pass

        for value in obj.values():
            found = _extract_keypoints(value)
            if found is not None:
                return found

    elif isinstance(obj, (list, tuple)):
        for value in obj:
            found = _extract_keypoints(value)
            if found is not None:
                return found

    return None


def draw_vitpose(frame, data):
    import numpy as np

    keypoints = _extract_keypoints(data)
    if keypoints is None:
        return

    h, w = frame.shape[:2]

    for point in keypoints:
        x = int(float(point[0]))
        y = int(float(point[1]))

        if 0 <= x < w and 0 <= y < h:
            cv2.circle(frame, (x, y), 4, (0, 255, 0), -1)


def top_class_info(data):
    """Return top class index and softmax confidence for classifiers."""
    try:
        import torch

        if not torch.is_tensor(data):
            return None

        values = data.detach().float().flatten()
        if values.numel() == 0:
            return None

        index = int(values.argmax().item())
        probabilities = torch.softmax(values, dim=0)
        confidence = float(probabilities[index].item())

        return index, confidence
    except Exception:
        return None


def annotate(frame, model, output, model_latency_ms, effective_fps, prediction_count=0):
    data = output.value if output is not None else None

    if model.name == "BlazePose" and data is not None:
        draw_blazepose(frame, data)

    elif model.name == "ViTPose" and data is not None:
        draw_vitpose(frame, data)

    lines = [
        f"Model: {model.name}",
        f"Device: {model.device_used()}",
        f"Camera/effective FPS: {effective_fps:.1f}",
        f"Inference: {model_latency_ms:.1f} ms",
    ]

    # Keep the standard benchmark information separate from model output.
    y = 30
    for line in lines:
        cv2.putText(
            frame,
            line,
            (15, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (0, 255, 0),
            2,
            cv2.LINE_AA,
        )
        y += 30

    if model.name in {"MoViNet-A0", "TSM-MobileNetV2"}:
        info = top_class_info(data)
        # Classification output starts below the benchmark stats so it
        # cannot overlap with the FPS/inference text.
        output_y = 175
        if info is not None:
            index, score = info
            cv2.putText(
                frame,
                f"Prediction: class {index}",
                (15, output_y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                frame,
                f"Confidence: {score:.3f}",
                (15, output_y + 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )
        else:
            cv2.putText(
                frame,
                "Prediction: waiting for model output...",
                (15, output_y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )

        cv2.putText(
            frame,
            f"Predictions: {prediction_count}",
            (15, output_y + 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            (0, 255, 0),
            2,
            cv2.LINE_AA,
        )

    cv2.putText(
        frame,
        "Q / ESC = stop",
        (15, frame.shape[0] - 20),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.62,
        (0, 255, 0),
        2,
        cv2.LINE_AA,
    )


def benchmark_one(
    model,
    camera_index: int,
    requested_device: str,
    duration: float,
    warmup_frames: int,
    width: int | None,
    height: int | None,
):
    process = psutil.Process(os.getpid())

    cap = open_camera(camera_index, width, height)

    camera_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    camera_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # CAP_PROP_FPS is frequently -1/0 for Windows webcams.
    # The model adapters need a positive FPS because BlazePose uses
    # frame_index * 1000 / fps as its MediaPipe VIDEO timestamp.
    reported_camera_fps = cap.get(cv2.CAP_PROP_FPS)
    nominal_camera_fps = (
        float(reported_camera_fps)
        if reported_camera_fps and reported_camera_fps > 0
        else 30.0
    )

    initial_device = requested_device_for(
        model,
        requested_device,
    )

    result = Result(
        model=model.name,
        family=model.family,
        task=model.task,
        input_type=model.input_type,
        implementation=model.implementation,
        device_requested=requested_device,
        device_used="CPU" if initial_device == "cpu" else "cuda",
        video_width=camera_width,
        video_height=camera_height,
        video_fps=nominal_camera_fps,
    )

    try:
        print()
        print("=" * 110)
        print(f"MODEL: {model.name}")
        print("=" * 110)
        print(
            f"Camera: {camera_width}x{camera_height} "
            f"(reported {reported_camera_fps:.2f} FPS; "
            f"model timestamp base {nominal_camera_fps:.2f} FPS)"
        )
        print(f"Requested device: {requested_device}")

        if requested_device == "cuda":
            import torch
            if not torch.cuda.is_available():
                raise RuntimeError(
                    "CUDA requested, but torch.cuda.is_available() is False."
                )

        before_ram = process.memory_info().rss / 1024**2

        load_start = time.perf_counter()
        model._device_used = initial_device
        model.load(requested_device)
        model.synchronize()
        result.load_ms = (time.perf_counter() - load_start) * 1000.0

        result.device_used = model.device_used()
        result.ram_after_load_mb = (
            process.memory_info().rss / 1024**2
        )

        try:
            result.parameters = model.parameter_count()
        except Exception:
            pass

        try:
            result.model_size_mb = model.model_size_mb()
        except Exception:
            pass

        print(f"Load time: {result.load_ms:.2f} ms")
        print(f"Actual device: {result.device_used}")
        print(f"Parameters: {result.parameters or '-'}")
        print(
            "Model memory: "
            + (
                f"{result.model_size_mb:.2f} MB"
                if result.model_size_mb is not None
                else "-"
            )
        )

        # Warmup with real webcam frames.
        model.reset()

        for i in range(warmup_frames):
            ok, frame = cap.read()
            if not ok:
                continue
            model.process_frame(
                frame,
                i,
                nominal_camera_fps,
            )

        model.synchronize()
        model.reset()

        if (
            requested_device == "cuda"
            and result.device_used.lower() == "cuda"
        ):
            import torch
            torch.cuda.reset_peak_memory_stats()

        latencies = []
        cpu_samples = []
        peak_ram_delta = 0.0
        peak_vram = None
        frames_seen = 0
        errors = 0
        prediction_count = 0
        last_prediction = None

        start = time.perf_counter()
        last_display_fps = 0.0
        fps_window_start = start
        fps_window_frames = 0

        print()
        print("LIVE FEED ACTIVE - move in front of the camera.")
        print("The model runs on the selected laptop hardware.")
        print()

        while True:
            now = time.perf_counter()
            if now - start >= duration:
                break

            ok, frame = cap.read()
            if not ok:
                continue

            frame_index = frames_seen
            frames_seen += 1
            fps_window_frames += 1

            try:
                model.synchronize()
                t0 = time.perf_counter()

                output = model.process_frame(
                    frame,
                    frame_index,
                    nominal_camera_fps,
                )

                model.synchronize()
                latency_ms = (
                    time.perf_counter() - t0
                ) * 1000.0

                # ModelOutput(None) is how TSM signals
                # that its 8-frame temporal buffer is not full yet.
                valid_inference = (
                    output is not None
                    and getattr(output, "value", None) is not None
                )

                if valid_inference:
                    latencies.append(latency_ms)
                    if model.name in {"MoViNet-A0", "TSM-MobileNetV2"}:
                        info = top_class_info(output.value)
                        if info is not None:
                            prediction_count += 1
                            last_prediction = info

                rss = process.memory_info().rss / 1024**2
                peak_ram_delta = max(
                    peak_ram_delta,
                    rss - result.ram_after_load_mb,
                )

                if (
                    result.device_used.lower() == "cuda"
                    and frames_seen % 20 == 0
                ):
                    import torch
                    peak_vram = max(
                        peak_vram or 0.0,
                        torch.cuda.max_memory_allocated() / 1024**2,
                    )

                if frames_seen % 20 == 0:
                    cpu_samples.append(
                        process.cpu_percent(0.05)
                    )

                # Effective display/camera throughput.
                elapsed_fps = time.perf_counter() - fps_window_start
                if elapsed_fps >= 1.0:
                    last_display_fps = (
                        fps_window_frames / elapsed_fps
                    )
                    fps_window_frames = 0
                    fps_window_start = time.perf_counter()

                annotate(
                    frame,
                    model,
                    output,
                    latency_ms,
                    last_display_fps,
                    prediction_count,
                )

                cv2.imshow(
                    "Laptop Model Benchmark",
                    frame,
                )

                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    print("\nStopped by user.")
                    break

            except Exception as exc:
                errors += 1
                if errors <= 5:
                    print(
                        f"\nFrame {frame_index} error: "
                        f"{type(exc).__name__}: {exc}"
                    )

        measured_s = time.perf_counter() - start

        result.frames_seen = frames_seen
        result.successful_inferences = len(latencies)
        result.errors = errors
        result.peak_ram_delta_mb = peak_ram_delta

        # The webcam's CAP_PROP_FPS is not reliable on Windows.
        # Use the actual measured delivery rate when available.
        result.video_fps = (
            frames_seen / measured_s
            if measured_s > 0 and frames_seen > 0
            else nominal_camera_fps
        )
        result.avg_process_cpu_percent = (
            statistics.mean(cpu_samples)
            if cpu_samples
            else 0.0
        )
        result.peak_vram_allocated_mb = peak_vram

        # This is the model throughput, not the camera FPS.
        if latencies:
            result.avg_ms = statistics.mean(latencies)
            result.p50_ms = percentile(latencies, 50)
            result.p95_ms = percentile(latencies, 95)
            result.p99_ms = percentile(latencies, 99)
            result.min_ms = min(latencies)
            result.max_ms = max(latencies)
            result.total_inference_s = sum(latencies) / 1000.0
            result.output_fps = len(latencies) / measured_s
        else:
            result.status = "ERROR"
            result.error = "No completed model inferences."

        print()
        print(f"Frames received : {result.frames_seen}")
        print(f"Completed       : {result.successful_inferences}")
        print(f"Errors          : {result.errors}")
        if model.name in {"MoViNet-A0", "TSM-MobileNetV2"}:
            print(f"Predictions     : {prediction_count}")
            if last_prediction is not None:
                idx, conf = last_prediction
                print(f"Last prediction : class {idx} (confidence {conf:.3f})")
        print(f"Average latency : {result.avg_ms:.2f} ms")
        print(f"P50             : {result.p50_ms:.2f} ms")
        print(f"P95             : {result.p95_ms:.2f} ms")
        print(f"P99             : {result.p99_ms:.2f} ms")
        print(f"Min / Max       : {result.min_ms:.2f} / {result.max_ms:.2f} ms")
        print(f"Model FPS       : {result.output_fps:.2f}")
        print(f"CPU             : {result.avg_process_cpu_percent:.1f}%")
        print(f"RAM delta       : {result.peak_ram_delta_mb:.1f} MB")

        if result.peak_vram_allocated_mb is not None:
            print(
                f"Peak VRAM       : "
                f"{result.peak_vram_allocated_mb:.1f} MB"
            )

        return result

    except Exception as exc:
        result.status = "ERROR"
        result.error = f"{type(exc).__name__}: {exc}"
        print(f"ERROR: {result.error}")
        return result

    finally:
        cap.release()
        try:
            model.close()
        except Exception:
            pass
        gc.collect()
        cv2.destroyAllWindows()


def save_results(results):
    Path("results").mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_path = Path("results") / f"laptop_camera_{timestamp}.json"
    csv_path = Path("results") / f"laptop_camera_{timestamp}.csv"

    payload = [asdict(r) for r in results]

    json_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    if payload:
        with csv_path.open(
            "w",
            newline="",
            encoding="utf-8",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=list(payload[0].keys()),
            )
            writer.writeheader()
            writer.writerows(payload)

    return json_path, csv_path


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Live laptop-camera benchmark using the same "
            "model adapters as benchmark.py."
        )
    )
    parser.add_argument(
        "--models",
        default="all",
        help="all or comma-separated: blazepose,movinet,tsm,vitpose",
    )
    parser.add_argument(
        "--device",
        choices=["cpu", "cuda"],
        default="cuda",
        help="Hardware for Torch models. BlazePose remains CPU-only.",
    )
    parser.add_argument(
        "--duration",
        type=float,
        default=30.0,
    )
    parser.add_argument(
        "--warmup",
        type=int,
        default=10,
    )
    parser.add_argument(
        "--camera",
        type=int,
        default=0,
    )
    parser.add_argument("--width", type=int, default=None)
    parser.add_argument("--height", type=int, default=None)

    args = parser.parse_args()

    models = select_models(args.models)

    print("=" * 110)
    print("LAPTOP LIVE MODEL BENCHMARK")
    print("=" * 110)
    print(f"Models   : {', '.join(m.name for m in models)}")
    print(f"Device   : {args.device}")
    print(f"Duration : {args.duration:.1f}s per model")
    print(f"Warmup   : {args.warmup} frame(s)")
    print()
    print(
        "A live camera window is shown while each model is running."
    )
    print(
        "BlazePose/ViTPose show pose points; MoViNet/TSM show top class index."
    )

    results = []

    for model in models:
        result = benchmark_one(
            model,
            args.camera,
            args.device,
            args.duration,
            args.warmup,
            args.width,
            args.height,
        )
        results.append(result)

    json_path, csv_path = save_results(results)

    print()
    print("=" * 120)
    print("FINAL LAPTOP RESULTS")
    print("=" * 120)
    print(
        f"{'Model':<22}"
        f"{'Status':<9}"
        f"{'Avg ms':>10}"
        f"{'P95':>10}"
        f"{'FPS':>10}"
        f"{'Device':>12}"
        f"{'CPU':>9}"
        f"{'RAM Δ':>10}"
    )
    print("-" * 120)

    for r in results:
        print(
            f"{r.model:<22}"
            f"{r.status:<9}"
            f"{r.avg_ms:>10.2f}"
            f"{r.p95_ms:>10.2f}"
            f"{r.output_fps:>10.2f}"
            f"{r.device_used:>12}"
            f"{r.avg_process_cpu_percent:>8.1f}%"
            f"{r.peak_ram_delta_mb:>9.1f}M"
        )

    print()
    print(f"JSON: {json_path}")
    print(f"CSV : {csv_path}")


if __name__ == "__main__":
    main()
