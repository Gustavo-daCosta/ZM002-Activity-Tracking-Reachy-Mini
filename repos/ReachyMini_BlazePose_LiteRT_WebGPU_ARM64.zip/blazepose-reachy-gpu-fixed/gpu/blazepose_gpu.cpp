
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "absl/types/span.h"
#include "litert/cc/litert_compiled_model.h"
#include "litert/cc/litert_environment.h"
#include "litert/cc/litert_options.h"
#include "litert/cc/litert_tensor_buffer.h"

namespace {

constexpr int kDetectorSize = 224;
constexpr int kLandmarkSize = 256;
constexpr int kDetectorBoxes = 2254;
constexpr int kDetectorCoords = 12;
constexpr float kDetectorScoreThreshold = 0.5f;
constexpr float kNmsThreshold = 0.3f;

struct Anchor {
  float x;
  float y;
  float w;
  float h;
};

struct Detection {
  float score = 0.0f;
  float cx = 0.0f;
  float cy = 0.0f;
  float w = 0.0f;
  float h = 0.0f;
  float keypoints[8]{};
};

struct Roi {
  float cx = 0.5f;
  float cy = 0.5f;
  float size = 1.0f;
  float rotation = 0.0f;
};

struct Landmark {
  float x = 0.0f;
  float y = 0.0f;
  float z = 0.0f;
  float visibility = 0.0f;
  float presence = 0.0f;
};

float sigmoid(float x) {
  x = std::max(-100.0f, std::min(100.0f, x));
  return 1.0f / (1.0f + std::exp(-x));
}

float normalize_angle(float angle) {
  constexpr float pi = 3.14159265358979323846f;
  constexpr float two_pi = 2.0f * pi;
  return angle - two_pi * std::floor((angle + pi) / two_pi);
}

std::vector<Anchor> make_detector_anchors() {
  std::vector<Anchor> anchors;

  constexpr float min_scale = 0.1484375f;
  constexpr float max_scale = 0.75f;
  constexpr int strides[] = {8, 16, 32, 32, 32};

  for (int layer = 0; layer < 5;) {
    int last = layer;
    while (last < 5 && strides[last] == strides[layer]) {
      ++last;
    }

    for (int l = layer; l < last; ++l) {
      const float scale =
          min_scale +
          (max_scale - min_scale) *
              static_cast<float>(l) / 4.0f;

      // aspect ratio = 1 and fixed_anchor_size = true.
      // Repeated stride layers intentionally produce one anchor per cell.
      const int feature = static_cast<int>(
          std::ceil(static_cast<float>(kDetectorSize) / strides[l]));

      for (int y = 0; y < feature; ++y) {
        for (int x = 0; x < feature; ++x) {
          const float cx =
              (x + 0.5f) / static_cast<float>(feature);
          const float cy =
              (y + 0.5f) / static_cast<float>(feature);

          // The pose detector uses the interpolated-scale anchor in
          // addition to the aspect-ratio-1 anchor. The model therefore
          // has two anchors per spatial location.
          anchors.push_back({cx, cy, 1.0f, 1.0f});
          anchors.push_back({cx, cy, 1.0f, 1.0f});

          (void)scale;
        }
      }
    }

    layer = last;
  }

  if (anchors.size() != kDetectorBoxes) {
    throw std::runtime_error(
        "BlazePose detector anchor count mismatch: got " +
        std::to_string(anchors.size()) +
        ", expected " + std::to_string(kDetectorBoxes));
  }

  return anchors;
}

// MediaPipe's detector graph uses FIT letterboxing and a [-1, 1] input range.
void resize_letterbox_rgb(
    const uint8_t* rgb,
    int src_w,
    int src_h,
    float* dst) {

  const float scale = std::min(
      static_cast<float>(kDetectorSize) / src_w,
      static_cast<float>(kDetectorSize) / src_h);

  const int resized_w =
      std::max(1, static_cast<int>(std::round(src_w * scale)));
  const int resized_h =
      std::max(1, static_cast<int>(std::round(src_h * scale)));

  const float pad_x =
      0.5f * (kDetectorSize - resized_w);
  const float pad_y =
      0.5f * (kDetectorSize - resized_h);

  std::fill(
      dst,
      dst + kDetectorSize * kDetectorSize * 3,
      -1.0f);

  for (int y = 0; y < resized_h; ++y) {
    const float sy =
        (static_cast<float>(y) + 0.5f) / scale - 0.5f;
    const int y0 = std::clamp(
        static_cast<int>(std::floor(sy)), 0, src_h - 1);
    const int y1 = std::clamp(y0 + 1, 0, src_h - 1);
    const float fy = sy - std::floor(sy);

    for (int x = 0; x < resized_w; ++x) {
      const float sx =
          (static_cast<float>(x) + 0.5f) / scale - 0.5f;
      const int x0 = std::clamp(
          static_cast<int>(std::floor(sx)), 0, src_w - 1);
      const int x1 = std::clamp(x0 + 1, 0, src_w - 1);
      const float fx = sx - std::floor(sx);

      const int dx = std::clamp(
          static_cast<int>(std::round(x + pad_x)),
          0, kDetectorSize - 1);
      const int dy = std::clamp(
          static_cast<int>(std::round(y + pad_y)),
          0, kDetectorSize - 1);

      const uint8_t* p00 =
          rgb + (y0 * src_w + x0) * 3;
      const uint8_t* p01 =
          rgb + (y0 * src_w + x1) * 3;
      const uint8_t* p10 =
          rgb + (y1 * src_w + x0) * 3;
      const uint8_t* p11 =
          rgb + (y1 * src_w + x1) * 3;

      float* out =
          dst + (dy * kDetectorSize + dx) * 3;

      for (int c = 0; c < 3; ++c) {
        const float a =
            p00[c] * (1.0f - fx) + p01[c] * fx;
        const float b =
            p10[c] * (1.0f - fx) + p11[c] * fx;
        const float value =
            (a * (1.0f - fy) + b * fy) / 255.0f;

        out[c] = value * 2.0f - 1.0f;
      }
    }
  }
}

std::vector<Detection> decode_detector(
    const float* boxes,
    const float* scores,
    const std::vector<Anchor>& anchors) {

  std::vector<Detection> detections;
  detections.reserve(16);

  for (int i = 0; i < kDetectorBoxes; ++i) {
    const float score = sigmoid(scores[i]);
    if (score < kDetectorScoreThreshold) {
      continue;
    }

    const float* p =
        boxes + i * kDetectorCoords;

    // MediaPipe's reverse_output_order=true means the x/y pairs
    // are represented in the detector's reversed coordinate order.
    // For this model the graph ultimately interprets p[0..3] as
    // center-y, center-x, height, width.
    const Anchor& a = anchors[i];

    const float cy =
        p[0] / kDetectorSize + a.y;
    const float cx =
        p[1] / kDetectorSize + a.x;
    const float h =
        p[2] / kDetectorSize;
    const float w =
        p[3] / kDetectorSize;

    Detection d;
    d.score = score;
    d.cx = cx;
    d.cy = cy;
    d.w = w;
    d.h = h;

    for (int k = 0; k < 4; ++k) {
      d.keypoints[k * 2 + 0] =
          (p[4 + k * 2 + 1] / kDetectorSize + a.x);
      d.keypoints[k * 2 + 1] =
          (p[4 + k * 2 + 0] / kDetectorSize + a.y);
    }

    detections.push_back(d);
  }

  std::sort(
      detections.begin(),
      detections.end(),
      [](const Detection& a, const Detection& b) {
        return a.score > b.score;
      });

  std::vector<Detection> kept;

  auto iou = [](const Detection& a, const Detection& b) {
    const float ax0 = a.cx - a.w * 0.5f;
    const float ay0 = a.cy - a.h * 0.5f;
    const float ax1 = a.cx + a.w * 0.5f;
    const float ay1 = a.cy + a.h * 0.5f;

    const float bx0 = b.cx - b.w * 0.5f;
    const float by0 = b.cy - b.h * 0.5f;
    const float bx1 = b.cx + b.w * 0.5f;
    const float by1 = b.cy + b.h * 0.5f;

    const float ix0 = std::max(ax0, bx0);
    const float iy0 = std::max(ay0, by0);
    const float ix1 = std::min(ax1, bx1);
    const float iy1 = std::min(ay1, by1);

    const float iw = std::max(0.0f, ix1 - ix0);
    const float ih = std::max(0.0f, iy1 - iy0);
    const float inter = iw * ih;

    const float area_a = std::max(0.0f, ax1 - ax0) *
                         std::max(0.0f, ay1 - ay0);
    const float area_b = std::max(0.0f, bx1 - bx0) *
                         std::max(0.0f, by1 - by0);

    const float denom = area_a + area_b - inter;
    return denom > 0.0f ? inter / denom : 0.0f;
  };

  for (const auto& candidate : detections) {
    bool suppressed = false;

    for (const auto& existing : kept) {
      if (iou(candidate, existing) >= kNmsThreshold) {
        suppressed = true;
        break;
      }
    }

    if (!suppressed) {
      kept.push_back(candidate);
      if (kept.size() == 1) {
        // The benchmark uses one pose, matching num_poses=1.
        break;
      }
    }
  }

  return kept;
}



void remove_detector_letterbox(
    std::vector<Detection>& detections,
    int width,
    int height) {

  const float scale = std::min(
      static_cast<float>(kDetectorSize) / width,
      static_cast<float>(kDetectorSize) / height);

  const float resized_w = width * scale;
  const float resized_h = height * scale;
  const float pad_x =
      0.5f * (kDetectorSize - resized_w);
  const float pad_y =
      0.5f * (kDetectorSize - resized_h);

  auto unproject_x = [&](float x) {
    return (x * kDetectorSize - pad_x) /
           std::max(1.0f, resized_w);
  };

  auto unproject_y = [&](float y) {
    return (y * kDetectorSize - pad_y) /
           std::max(1.0f, resized_h);
  };

  for (auto& d : detections) {
    const float x0 = unproject_x(d.cx - d.w * 0.5f);
    const float x1 = unproject_x(d.cx + d.w * 0.5f);
    const float y0 = unproject_y(d.cy - d.h * 0.5f);
    const float y1 = unproject_y(d.cy + d.h * 0.5f);

    d.cx = (x0 + x1) * 0.5f;
    d.cy = (y0 + y1) * 0.5f;
    d.w = std::abs(x1 - x0);
    d.h = std::abs(y1 - y0);

    for (int k = 0; k < 4; ++k) {
      d.keypoints[k * 2 + 0] =
          unproject_x(d.keypoints[k * 2 + 0]);
      d.keypoints[k * 2 + 1] =
          unproject_y(d.keypoints[k * 2 + 1]);
    }
  }
}
Roi detection_to_roi(
    const Detection& d,
    int width,
    int height) {

  // Full-body MediaPipe pose detector:
  // keypoint 0 = mid hip, keypoint 1 = full-body size/rotation.
  const float x0 = d.keypoints[0];
  const float y0 = d.keypoints[1];
  const float x1 =
      (d.cx - d.w * 0.5f + d.cx + d.w * 0.5f) * 0.5f;
  const float y1 =
      (d.cy - d.h * 0.5f + d.cy + d.h * 0.5f) * 0.5f;

  const float target_angle =
      3.14159265358979323846f * 0.5f;

  const float rotation =
      normalize_angle(
          target_angle -
          std::atan2(-(y1 - y0), x1 - x0));

  const float sx = d.keypoints[2];
  const float sy = d.keypoints[3];

  const float dx = (sx - x0) * width;
  const float dy = (sy - y0) * height;

  const float box_size =
      std::sqrt(dx * dx + dy * dy) * 2.0f;

  // MediaPipe RectTransformationCalculator scales the detector
  // rectangle by 1.5 for the landmark ROI.
  const float roi_px =
      std::max(1.0f, box_size * 1.5f);

  Roi roi;
  roi.cx = x0;
  roi.cy = y0;
  roi.size = roi_px /
             static_cast<float>(std::max(width, height));
  roi.rotation = rotation;

  return roi;
}

void crop_rotated_roi(
    const uint8_t* rgb,
    int src_w,
    int src_h,
    const Roi& roi,
    float* dst) {

  // The ROI is square and rotated. This is the equivalent of the
  // landmark ImageToTensor step with keep_aspect_ratio=true.
  const float scale =
      roi.size * static_cast<float>(
          std::max(src_w, src_h));

  const float cs = std::cos(roi.rotation);
  const float sn = std::sin(roi.rotation);

  const float cx = roi.cx * src_w;
  const float cy = roi.cy * src_h;

  for (int y = 0; y < kLandmarkSize; ++y) {
    const float v =
        (static_cast<float>(y) + 0.5f) /
            kLandmarkSize -
        0.5f;

    for (int x = 0; x < kLandmarkSize; ++x) {
      const float u =
          (static_cast<float>(x) + 0.5f) /
              kLandmarkSize -
          0.5f;

      const float rx = u * scale;
      const float ry = v * scale;

      const float sx =
          cx + rx * cs - ry * sn;
      const float sy =
          cy + rx * sn + ry * cs;

      const int x0 =
          static_cast<int>(std::floor(sx));
      const int y0 =
          static_cast<int>(std::floor(sy));

      float* out =
          dst + (y * kLandmarkSize + x) * 3;

      if (x0 < 0 || x0 >= src_w ||
          y0 < 0 || y0 >= src_h) {
        out[0] = out[1] = out[2] = 0.0f;
        continue;
      }

      const int x1 = std::min(x0 + 1, src_w - 1);
      const int y1 = std::min(y0 + 1, src_h - 1);
      const float fx = sx - x0;
      const float fy = sy - y0;

      const uint8_t* p00 =
          rgb + (y0 * src_w + x0) * 3;
      const uint8_t* p01 =
          rgb + (y0 * src_w + x1) * 3;
      const uint8_t* p10 =
          rgb + (y1 * src_w + x0) * 3;
      const uint8_t* p11 =
          rgb + (y1 * src_w + x1) * 3;

      for (int c = 0; c < 3; ++c) {
        const float a =
            p00[c] * (1.0f - fx) + p01[c] * fx;
        const float b =
            p10[c] * (1.0f - fx) + p11[c] * fx;

        out[c] =
            (a * (1.0f - fy) + b * fy) / 255.0f;
      }
    }
  }
}

}  // namespace

extern "C" {

struct BlazePoseGpu {
  std::unique_ptr<litert::Environment> env;
  litert::CompiledModel detector;
  litert::CompiledModel landmarks;

  std::vector<litert::TensorBuffer> detector_inputs;
  std::vector<litert::TensorBuffer> detector_outputs;
  std::vector<litert::TensorBuffer> landmark_inputs;
  std::vector<litert::TensorBuffer> landmark_outputs;

  std::vector<Anchor> anchors;
  std::vector<float> detector_input;
  std::vector<float> landmark_input;
  std::vector<float> boxes;
  std::vector<float> scores;
  std::vector<float> landmark_values;
  std::string last_error;

  BlazePoseGpu(
      std::unique_ptr<litert::Environment> e,
      litert::CompiledModel&& d,
      litert::CompiledModel&& l)
      : env(std::move(e)),
        detector(std::move(d)),
        landmarks(std::move(l)),
        anchors(make_detector_anchors()),
        detector_input(
            kDetectorSize * kDetectorSize * 3),
        landmark_input(
            kLandmarkSize * kLandmarkSize * 3) {}
};

static bool copy_float_output(
    litert::TensorBuffer& buffer,
    std::vector<float>& destination) {

  auto size_result = buffer.Size();
  if (!size_result) {
    return false;
  }

  const size_t bytes = *size_result;
  if (bytes % sizeof(float) != 0) {
    return false;
  }

  const size_t count = bytes / sizeof(float);
  destination.resize(count);

  auto lock =
      litert::TensorBufferScopedLock::Create<const float>(
          buffer,
          litert::TensorBuffer::LockMode::kRead);

  if (!lock) {
    return false;
  }

  std::memcpy(
      destination.data(),
      lock->second,
      bytes);

  return true;
}

BlazePoseGpu* blazepose_gpu_create(
    const char* detector_path,
    const char* landmark_path) {

  try {
    auto env_result =
        litert::Environment::Create({});

    if (!env_result) {
      throw std::runtime_error(
          "LiteRT Environment::Create failed");
    }

    auto options_result =
        litert::Options::Create();

    if (!options_result) {
      throw std::runtime_error(
          "LiteRT Options::Create failed");
    }

    auto options = std::move(*options_result);

    options.SetHardwareAccelerators(
        litert::HwAccelerators::kGpu);

    auto env = std::make_unique<litert::Environment>(
        std::move(*env_result));

    auto detector_result =
        litert::CompiledModel::Create(
            *env,
            detector_path,
            options);

    if (!detector_result) {
      throw std::runtime_error(
          "GPU CompiledModel creation failed for detector");
    }

    auto landmark_result =
        litert::CompiledModel::Create(
            *env,
            landmark_path,
            options);

    if (!landmark_result) {
      throw std::runtime_error(
          "GPU CompiledModel creation failed for landmarks");
    }

    auto* state = new BlazePoseGpu(
        std::move(env),
        std::move(*detector_result),
        std::move(*landmark_result));

    auto detector_inputs =
        state->detector.CreateInputBuffers();

    auto detector_outputs =
        state->detector.CreateOutputBuffers();

    auto landmark_inputs =
        state->landmarks.CreateInputBuffers();

    auto landmark_outputs =
        state->landmarks.CreateOutputBuffers();

    if (!detector_inputs ||
        !detector_outputs ||
        !landmark_inputs ||
        !landmark_outputs) {
      delete state;
      throw std::runtime_error(
          "LiteRT TensorBuffer creation failed");
    }

    state->detector_inputs =
        std::move(*detector_inputs);
    state->detector_outputs =
        std::move(*detector_outputs);
    state->landmark_inputs =
        std::move(*landmark_inputs);
    state->landmark_outputs =
        std::move(*landmark_outputs);

    return state;

  } catch (...) {
    return nullptr;
  }
}

int blazepose_gpu_last_error(
    BlazePoseGpu* state,
    char* buffer,
    size_t buffer_size) {

  if (!state || !buffer || buffer_size == 0) {
    return 0;
  }

  const size_t n =
      std::min(
          buffer_size - 1,
          state->last_error.size());

  std::memcpy(
      buffer,
      state->last_error.data(),
      n);

  buffer[n] = '\0';
  return static_cast<int>(n);
}

int blazepose_gpu_infer(
    BlazePoseGpu* state,
    const uint8_t* rgb,
    int width,
    int height,
    float* landmarks33) {

  if (!state || !rgb ||
      !landmarks33 ||
      width <= 0 ||
      height <= 0) {
    return -1;
  }

  try {
    std::fill(
        landmarks33,
        landmarks33 + 33 * 4,
        std::numeric_limits<float>::quiet_NaN());

    resize_letterbox_rgb(
        rgb,
        width,
        height,
        state->detector_input.data());

    if (!state->detector_inputs[0].Write<float>(
            absl::MakeConstSpan(
                state->detector_input))) {
      throw std::runtime_error(
          "Writing detector input failed");
    }

    auto detector_run =
        state->detector.Run(
            state->detector_inputs,
            state->detector_outputs);

    if (!detector_run) {
      throw std::runtime_error(
          "Detector GPU inference failed");
    }

    int boxes_index = -1;
    int scores_index = -1;

    for (size_t i = 0;
         i < state->detector_outputs.size();
         ++i) {

      auto size_result =
          state->detector_outputs[i].Size();

      if (!size_result) {
        continue;
      }

      const size_t bytes = *size_result;

      if (bytes ==
          kDetectorBoxes *
              kDetectorCoords *
              sizeof(float)) {
        boxes_index = static_cast<int>(i);
      } else if (
          bytes ==
          kDetectorBoxes *
              sizeof(float)) {
        scores_index = static_cast<int>(i);
      }
    }

    if (boxes_index < 0 ||
        scores_index < 0) {
      throw std::runtime_error(
          "Unexpected BlazePose detector output sizes");
    }

    if (!copy_float_output(
            state->detector_outputs[boxes_index],
            state->boxes) ||
        !copy_float_output(
            state->detector_outputs[scores_index],
            state->scores)) {
      throw std::runtime_error(
          "Reading detector GPU outputs failed");
    }

    auto detections =
        decode_detector(
            state->boxes.data(),
            state->scores.data(),
            state->anchors);

    remove_detector_letterbox(
        detections,
        width,
        height);

    if (detections.empty()) {
      return 0;
    }

    const Roi roi =
        detection_to_roi(
            detections.front(),
            width,
            height);

    crop_rotated_roi(
        rgb,
        width,
        height,
        roi,
        state->landmark_input.data());

    if (!state->landmark_inputs[0].Write<float>(
            absl::MakeConstSpan(
                state->landmark_input))) {
      throw std::runtime_error(
          "Writing landmark input failed");
    }

    auto landmark_run =
        state->landmarks.Run(
            state->landmark_inputs,
            state->landmark_outputs);

    if (!landmark_run) {
      throw std::runtime_error(
          "Landmark GPU inference failed");
    }

    int landmark_index = -1;
    int flag_index = -1;

    for (size_t i = 0;
         i < state->landmark_outputs.size();
         ++i) {

      auto size_result =
          state->landmark_outputs[i].Size();

      if (!size_result) {
        continue;
      }

      const size_t bytes = *size_result;

      if (bytes == 195 * sizeof(float)) {
        landmark_index = static_cast<int>(i);
      } else if (bytes == sizeof(float)) {
        flag_index = static_cast<int>(i);
      }
    }

    if (landmark_index < 0 ||
        flag_index < 0) {
      throw std::runtime_error(
          "Unexpected BlazePose landmark output sizes");
    }

    if (!copy_float_output(
            state->landmark_outputs[landmark_index],
            state->landmark_values)) {
      throw std::runtime_error(
          "Reading landmark GPU output failed");
    }

    float presence = 1.0f;

    std::vector<float> flag;
    if (copy_float_output(
            state->landmark_outputs[flag_index],
            flag) &&
        !flag.empty()) {
      presence = sigmoid(flag[0]);
    }

    if (presence < 0.5f) {
      return 0;
    }

    const float* raw =
        state->landmark_values.data();

    // 39 landmarks x 5 values:
    // x, y, z, visibility, presence.
    //
    // First 33 are the public pose landmarks.
    for (int i = 0; i < 33; ++i) {
      const float x = raw[i * 5 + 0] /
                      static_cast<float>(kLandmarkSize);
      const float y = raw[i * 5 + 1] /
                      static_cast<float>(kLandmarkSize);
      const float z = raw[i * 5 + 2];
      const float visibility =
          sigmoid(raw[i * 5 + 3]);
      const float landmark_presence =
          sigmoid(raw[i * 5 + 4]);

      // Transform local ROI coordinates back to full-image
      // normalized coordinates.
      const float local_x =
          x - 0.5f;
      const float local_y =
          y - 0.5f;

      const float scale =
          roi.size *
          static_cast<float>(
              std::max(width, height));

      const float cs =
          std::cos(roi.rotation);
      const float sn =
          std::sin(roi.rotation);

      const float px =
          roi.cx +
          (local_x * scale * cs -
           local_y * scale * sn) /
              static_cast<float>(width);

      const float py =
          roi.cy +
          (local_x * scale * sn +
           local_y * scale * cs) /
              static_cast<float>(height);

      landmarks33[i * 4 + 0] = px;
      landmarks33[i * 4 + 1] = py;
      landmarks33[i * 4 + 2] = visibility;
      landmarks33[i * 4 + 3] =
          landmark_presence;
    }

    return 1;

  } catch (const std::exception& exc) {
    state->last_error = exc.what();
    return -2;
  }
}

void blazepose_gpu_destroy(BlazePoseGpu* state) {
  delete state;
}

}  // extern "C"
