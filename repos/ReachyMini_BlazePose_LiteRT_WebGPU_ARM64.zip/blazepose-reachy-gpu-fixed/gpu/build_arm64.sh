#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

rm -rf build

cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_SYSTEM_NAME=Linux \
  -DCMAKE_SYSTEM_PROCESSOR=aarch64 \
  -DCMAKE_CXX_COMPILER=aarch64-linux-gnu-g++

cmake --build build -j4

echo
echo "Built:"
file libs/libblazepose_gpu.so
file bin/blazepose_gpu_inspector
