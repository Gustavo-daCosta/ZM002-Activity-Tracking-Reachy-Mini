#include <iostream>
#include <string>

#include "litert/cc/litert_environment.h"
#include "litert/cc/litert_compiled_model.h"
#include "litert/cc/litert_options.h"

using namespace litert;

void inspect_model(
    Environment& env,
    const std::string& path
) {
    std::cout << "\n========================================\n";
    std::cout << "MODEL: " << path << "\n";
    std::cout << "========================================\n";

    auto options_result = Options::Create();

    if (!options_result) {
        std::cerr << "Failed to create LiteRT options\n";
        return;
    }

    auto options = std::move(*options_result);

    options.SetHardwareAccelerators(
        HwAccelerators::kGpu
    );

    std::cout << "Creating GPU CompiledModel...\n";

    auto model_result =
        CompiledModel::Create(
            env,
            path,
            options
        );

    if (!model_result) {
        std::cerr
            << "GPU CompiledModel creation FAILED\n";
        return;
    }

    auto model = std::move(*model_result);

    std::cout
        << "GPU CompiledModel creation SUCCESS\n";

    auto inputs = model.CreateInputBuffers();

    if (!inputs) {
        std::cerr << "Failed to create input buffers\n";
        return;
    }

    auto outputs = model.CreateOutputBuffers();

    if (!outputs) {
        std::cerr << "Failed to create output buffers\n";
        return;
    }

    std::cout
        << "Input buffers : "
        << inputs->size()
        << "\n";

    std::cout
        << "Output buffers: "
        << outputs->size()
        << "\n";

    for (size_t i = 0; i < inputs->size(); ++i) {
        std::cout
            << "Input " << i
            << " WebGPU memory: "
            << ((*inputs)[i].IsWebGpuMemory() ? "YES" : "NO")
            << "\n";
    }

    for (size_t i = 0; i < outputs->size(); ++i) {
        std::cout
            << "Output " << i
            << " WebGPU memory: "
            << ((*outputs)[i].IsWebGpuMemory() ? "YES" : "NO")
            << "\n";
    }

    std::cout << "\nModel GPU setup successful.\n";
}


int main(int argc, char** argv) {

    if (argc != 3) {
        std::cerr
            << "Usage: " << argv[0]
            << " pose_detector.tflite "
            << "pose_landmarks_detector.tflite\n";
        return 1;
    }

    std::cout
        << "========================================\n"
        << "BlazePose LiteRT GPU Inspector\n"
        << "========================================\n";

    auto env_result = Environment::Create({});

    if (!env_result) {
        std::cerr
            << "Failed to create LiteRT environment\n";
        return 2;
    }

    auto env = std::move(*env_result);

    inspect_model(
        env,
        argv[1]
    );

    inspect_model(
        env,
        argv[2]
    );

    return 0;
}
