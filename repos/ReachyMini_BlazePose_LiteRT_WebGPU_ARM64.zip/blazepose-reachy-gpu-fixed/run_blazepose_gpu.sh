#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

export LD_LIBRARY_PATH="$PWD/gpu/libs${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

python3 reachy_blazepose_gpu_benchmark.py \
  --models blazepose \
  --duration "${DURATION:-30}" \
  --warmup "${WARMUP:-10}"
