
from __future__ import annotations

import ctypes
import gc
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from models.base import ModelAdapter, ModelOutput


ROOT = Path(__file__).resolve().parent.parent
GPU_DIR = ROOT / "gpu"

DEFAULT_LIBRARY = GPU_DIR / "libs" / "libblazepose_gpu.so"
DETECTOR_MODEL = GPU_DIR / "pose_detector.tflite"
LANDMARK_MODEL = GPU_DIR / "pose_landmarks_detector.tflite"


class NativeLandmark:
    def __init__(
        self,
        x: float,
        y: float,
        z: float,
        visibility: float,
        presence: float,
    ):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
        self.visibility = float(visibility)
        self.presence = float(presence)


class NativeBlazePoseOutput:
    """MediaPipe-like representation used by the existing renderer."""

    def __init__(self, landmarks: np.ndarray):
        self.pose_landmarks = [[
            NativeLandmark(*row)
            for row in landmarks
        ]]


class BlazePoseGPU(ModelAdapter):
    name = "BlazePose-GPU"
    family = "pose / skeleton"
    task = "2D human pose"
    input_type = "RGB frame"
    temporal = True
    implementation = "MediaPipe BlazePose models + LiteRT WebGPU"
    license = "Apache 2.0"

    always_cpu = False

    def __init__(
        self,
        library_path: Path = DEFAULT_LIBRARY,
        detector_path: Path = DETECTOR_MODEL,
        landmark_path: Path = LANDMARK_MODEL,
    ) -> None:
        super().__init__()
        self.library_path = Path(library_path)
        self.detector_path = Path(detector_path)
        self.landmark_path = Path(landmark_path)

        self.lib = None
        self.handle = None

    def load(self, device: str) -> None:
        if device.lower() not in {"gpu", "webgpu"}:
            raise ValueError(
                "BlazePose-GPU requires device='gpu' or device='webgpu'."
            )

        for path in (
            self.library_path,
            self.detector_path,
            self.landmark_path,
        ):
            if not path.exists():
                raise FileNotFoundError(path)

        self.lib = ctypes.CDLL(
            str(self.library_path),
            mode=ctypes.RTLD_LOCAL,
        )

        self.lib.blazepose_gpu_create.argtypes = [
            ctypes.c_char_p,
            ctypes.c_char_p,
        ]
        self.lib.blazepose_gpu_create.restype = ctypes.c_void_p

        self.lib.blazepose_gpu_infer.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_uint8),
            ctypes.c_int,
            ctypes.c_int,
            ctypes.POINTER(ctypes.c_float),
        ]
        self.lib.blazepose_gpu_infer.restype = ctypes.c_int

        self.lib.blazepose_gpu_destroy.argtypes = [
            ctypes.c_void_p,
        ]
        self.lib.blazepose_gpu_destroy.restype = None

        self.lib.blazepose_gpu_last_error.argtypes = [
            ctypes.c_void_p,
            ctypes.c_char_p,
            ctypes.c_size_t,
        ]
        self.lib.blazepose_gpu_last_error.restype = ctypes.c_int

        self.handle = self.lib.blazepose_gpu_create(
            str(self.detector_path).encode(),
            str(self.landmark_path).encode(),
        )

        if not self.handle:
            raise RuntimeError(
                "LiteRT BlazePose GPU initialization failed."
            )

        self._device_used = "GPU/WebGPU"

    def process_frame(
        self,
        frame,
        frame_index: int,
        fps: float,
    ) -> ModelOutput:
        del frame_index, fps

        if self.handle is None or self.lib is None:
            raise RuntimeError(
                "BlazePose-GPU is not loaded."
            )

        if frame is None:
            return ModelOutput(None)

        if frame.ndim != 3 or frame.shape[2] != 3:
            raise ValueError(
                f"Expected BGR image with 3 channels, got {frame.shape}"
            )

        rgb = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB,
        )

        rgb = np.ascontiguousarray(rgb, dtype=np.uint8)

        result = np.empty(
            (33, 4),
            dtype=np.float32,
        )

        rc = self.lib.blazepose_gpu_infer(
            self.handle,
            rgb.ctypes.data_as(
                ctypes.POINTER(ctypes.c_uint8)
            ),
            rgb.shape[1],
            rgb.shape[0],
            result.ctypes.data_as(
                ctypes.POINTER(ctypes.c_float)
            ),
        )

        if rc == 0:
            return ModelOutput(None)

        if rc < 0:
            error_buffer = ctypes.create_string_buffer(1024)
            self.lib.blazepose_gpu_last_error(
                self.handle,
                error_buffer,
                len(error_buffer),
            )

            message = error_buffer.value.decode(
                "utf-8",
                errors="replace",
            )

            raise RuntimeError(
                message or "Native BlazePose GPU inference failed."
            )

        return ModelOutput(
            NativeBlazePoseOutput(result)
        )

    def reset(self) -> None:
        # The GPU pipeline is stateless in this adapter. The detector is
        # currently evaluated for every benchmark frame, so reset is simply
        # a synchronization boundary.
        self.synchronize()

    def synchronize(self) -> None:
        # CompiledModel.Run() is synchronous for this implementation.
        pass

    def parameter_count(self) -> int | None:
        return None

    def model_size_mb(self) -> float | None:
        try:
            return (
                self.detector_path.stat().st_size
                + self.landmark_path.stat().st_size
            ) / (1024 * 1024)
        except OSError:
            return None

    def close(self) -> None:
        if self.handle is not None and self.lib is not None:
            self.lib.blazepose_gpu_destroy(self.handle)

        self.handle = None
        self.lib = None
        gc.collect()


def create_gpu_models() -> list[ModelAdapter]:
    return [BlazePoseGPU()]
