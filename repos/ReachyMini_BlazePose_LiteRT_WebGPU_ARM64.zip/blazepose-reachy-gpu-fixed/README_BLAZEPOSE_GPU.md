# BlazePose GPU — Reachy Mini benchmark

This repository is the existing Reachy Mini model-testing project with a **separate native BlazePose GPU implementation** added under `gpu/` and `gpu_models/`.

The original CPU benchmark files are kept intact.

## What was added

```text
gpu/
├── CMakeLists.txt
├── blazepose_gpu.cpp
├── inspect_blazepose.cpp
├── pose_detector.tflite
├── pose_landmarks_detector.tflite
├── pose_landmarker_full.task
└── libs/
    ├── libLiteRt.so
    └── libLiteRtWebGpuAccelerator.so

gpu_models/
└── __init__.py

reachy_blazepose_gpu_benchmark.py
```

The native backend uses the two exact TFLite models extracted from the existing:

```text
pose_landmarker_full.task
```

and requests LiteRT GPU execution.

The Python benchmark keeps the same live-camera benchmark style as the existing `reachy_camera_benchmark.py`:

- Reachy Mini camera
- live browser feed
- skeleton drawing
- camera FPS
- model FPS
- inference latency
- P50 / P95 / P99
- CPU usage
- RAM delta
- model load time
- result CSV/JSON files

## Important implementation detail

The native GPU backend is not the old MediaPipe Python GPU delegate.

It is:

```text
Reachy Mini camera
        |
        v
Python benchmark
        |
        v
ctypes
        |
        v
native C++ BlazePose pipeline
        |
        +--> pose_detector.tflite
        |        |
        |        v
        |    LiteRT GPU/WebGPU
        |
        +--> ROI calculation
        |
        +--> pose_landmarks_detector.tflite
                 |
                 v
             LiteRT GPU/WebGPU
        |
        v
33 landmarks
        |
        v
Python skeleton renderer
```

The native C++ implementation performs the detector preprocessing, detector output decoding, pose ROI calculation, landmark ROI preprocessing, landmark output decoding and projection back to the camera image.

### Benchmarking caveat

The CPU MediaPipe Tasks implementation internally uses the MediaPipe pose detector/tracker graph and can reuse the previous pose ROI between frames.

The first GPU implementation deliberately evaluates the detector on every benchmark frame. This makes the GPU path self-contained and deterministic, but it is **not a byte-for-byte reproduction of MediaPipe's internal temporal tracking graph**.

Therefore:

- the benchmark timing infrastructure is directly comparable;
- the model files are the exact BlazePose Full models;
- GPU inference is native LiteRT;
- but detector/tracker scheduling is not yet identical to MediaPipe's CPU implementation.

That distinction is important when interpreting the final numbers.

## Build on Ubuntu x86_64

The native library must be cross-compiled for Reachy's ARM64 CPU.

The expected toolchain is:

```bash
sudo apt install gcc-aarch64-linux-gnu g++-aarch64-linux-gnu cmake ninja-build
```

The build expects the existing LiteRT source/build tree:

```text
~/LiteRT
~/LiteRT/build-movenet-gpu
```

and the existing ARM64 LiteRT build.

From this repository:

```bash
cd gpu

rm -rf build

cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_SYSTEM_NAME=Linux \
  -DCMAKE_SYSTEM_PROCESSOR=aarch64 \
  -DCMAKE_CXX_COMPILER=aarch64-linux-gnu-g++

cmake --build build -j4
```

The important output is:

```text
gpu/libs/libblazepose_gpu.so
gpu/bin/blazepose_gpu_inspector
```

## Verify ARM64

```bash
file gpu/libs/libblazepose_gpu.so
file gpu/bin/blazepose_gpu_inspector
```

Both must report ARM aarch64.

## Test GPU model initialization directly

On Reachy:

```bash
cd ~/blazepose-gpu
chmod +x blazepose_gpu_inspector

LD_LIBRARY_PATH="$PWD" \
./blazepose_gpu_inspector \
  pose_detector.tflite \
  pose_landmarks_detector.tflite
```

The expected successful state is:

```text
GPU CompiledModel creation SUCCESS
```

for both models, with GPU/WebGPU tensor buffers.

## Deploy the Python benchmark

Copy the repository to Reachy, or copy the relevant files.

The native libraries must be in:

```text
gpu/libs/
```

The Python benchmark is:

```bash
python3 reachy_blazepose_gpu_benchmark.py \
  --models blazepose \
  --duration 30 \
  --warmup 10
```

If the Reachy SDK environment is already active, this is normally:

```bash
python reachy_blazepose_gpu_benchmark.py --models blazepose
```

The benchmark prints a browser URL similar to:

```text
http://reachy-mini.local:8765/
```

Open that URL on the laptop.

## Run a shorter test

```bash
python reachy_blazepose_gpu_benchmark.py \
  --models blazepose \
  --duration 15 \
  --warmup 10
```

## Results

Results are written to:

```text
results/
```

as CSV and JSON, using the same `Result` structure as the existing Reachy camera benchmark.

## Model provenance

The models are the exact files extracted from:

```text
pose_landmarker_full.task
```

which contains:

```text
pose_detector.tflite
pose_landmarks_detector.tflite
```

No replacement BlazePose model is used.

## GPU runtime

The native code requests:

```cpp
options.SetHardwareAccelerators(
    litert::HwAccelerators::kGpu
);
```

The packaged ARM64 LiteRT WebGPU accelerator is:

```text
libLiteRtWebGpuAccelerator.so
```

The actual GPU device/runtime must still be verified on the Reachy itself. A successful cross-compilation only proves that the ARM64 binary was built correctly; it does not by itself prove that the Reachy's V3D GPU accepts every BlazePose operation.

## Original CPU benchmark

The original files remain available and can still be run exactly as before.

For example:

```bash
python reachy_camera_benchmark.py --models blazepose
```

The GPU benchmark is intentionally a separate entry point:

```bash
python reachy_blazepose_gpu_benchmark.py --models blazepose
```

This prevents the original CPU benchmark from being changed by the GPU experiment.
