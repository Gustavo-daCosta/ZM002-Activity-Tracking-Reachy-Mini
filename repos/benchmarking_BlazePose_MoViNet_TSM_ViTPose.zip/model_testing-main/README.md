# Reachy Mini — AI Model Performance Benchmark

This repository benchmarks four computer-vision models for a Reachy Mini movement-analysis project. It compares how the models perform on a development laptop with an NVIDIA GTX 1650 GPU and on the Reachy Mini's onboard computer, where inference runs on the CPU.

The main question is practical: **which model approaches can run fast enough on the hardware available for a live camera-based application?** This repository measures performance and resource use. It does not establish which model is most accurate at recognizing the project's target movements.

## Results at a glance

The following results are from the current live-camera tests. Latency is the average time for a model inference call; FPS is the measured model output throughput.

### Development laptop — NVIDIA GTX 1650

| Model | Status | Average latency | P95 latency | Output FPS | Device |
|---|---:|---:|---:|---:|---|
| BlazePose | OK | 44.14 ms | 58.55 ms | 19.89 | CPU |
| MoViNet-A0 | OK | 62.75 ms | 73.46 ms | 14.12 | CUDA |
| TSM-MobileNetV2 | OK | 42.56 ms | 50.87 ms | 19.98 | CUDA |
| ViTPose | OK | 55.81 ms | 61.13 ms | 16.13 | CUDA |

All four models completed successfully on the laptop. These results suggest that all are testable for a live application on this development machine, although none of the measured throughputs reaches 30 model outputs per second. BlazePose ran on CPU because the MediaPipe implementation used here is CPU-based; the other three used CUDA.

### Reachy Mini onboard computer — CPU inference

| Model | Status | Average latency | P95 latency | Output FPS | Camera FPS |
|---|---:|---:|---:|---:|---:|
| BlazePose | OK | 217.22 ms | 251.59 ms | 3.92 | 3.77 |
| MoViNet-A0 | OK | 529.44 ms | 604.71 ms | 1.77 | 1.77 |
| TSM-MobileNetV2 | OK | 2,053.89 ms | 2,130.01 ms | 0.46 | 0.49 |
| ViTPose | OK | 5,829.31 ms | 5,906.60 ms | 0.17 | 0.17 |

All models ran on the Reachy Mini, but performance was much slower than on the laptop. BlazePose was the fastest of the tested models on the robot at about 3.9 outputs per second. MoViNet-A0 was slower at about 1.8 FPS, while TSM-MobileNetV2 and ViTPose were too slow for responsive live use in this configuration. The status `OK` means the benchmark completed; it does **not** mean the model is fast enough for deployment.

These are measured results from the current test runs, not universal performance guarantees. Results can change with camera resolution, software versions, thermal conditions, model settings, and background load.

## What the repository does

The project provides scripts and model adapters to:

- benchmark four pretrained human-pose or video-action models;
- run repeatable offline comparisons using one fixed video;
- benchmark models live using a laptop camera;
- benchmark models live using the Reachy Mini's onboard camera;
- select CPU or CUDA for the supported PyTorch models;
- measure latency, throughput, process CPU use, RAM growth and other available model metadata;
- export results to timestamped CSV and JSON files for later analysis.

It is a performance-testing repository, not a complete movement-recognition product. It does not currently provide a validated classifier for specific physiotherapy exercises, clinical evaluation, or proof that a prediction is correct.

## Models included

| Model | Approach | What it produces | Notes |
|---|---|---|---|
| **BlazePose** | Pose estimation | 2D body landmarks | MediaPipe-based; CPU in this implementation |
| **ViTPose** | Pose estimation | 2D body keypoints | Top-down estimator; the benchmark supplies a fixed full-frame person box rather than timing a separate detector |
| **MoViNet-A0** | Direct video action recognition | Action-class scores | Uses a PyTorch port with pretrained Kinetics-600 weights |
| **TSM-MobileNetV2** | Direct video action recognition | Action-class scores | Uses the TSM MobileNetV2 model with 8-frame input windows |

The two pose-estimation models first represent the person as body keypoints. Those keypoints could be used by a later movement-analysis stage. MoViNet-A0 and TSM-MobileNetV2 instead classify visual/video input directly. These are different approaches and solve different intermediate tasks, so raw speed comparisons do not show which approach is more accurate for a particular movement.

The action-recognition models were pretrained on general action datasets, not specifically validated on this project's target exercise classes. Their output labels should not be treated as reliable exercise recognition without a separate, task-specific evaluation.

## Repository layout

```text
model_testing-main/
├── main.py                     # Record a fixed video and run offline benchmarks
├── benchmark.py                # Offline benchmark runner and result export
├── laptop_camera_benchmark.py  # Live benchmark using a laptop/webcam
├── reachy_camera_benchmark.py  # Live benchmark using Reachy Mini's camera
├── compare_results.py          # Compare saved benchmark JSON results
├── models/
│   ├── base.py                 # Shared model interface and result structures
│   ├── registry.py             # Model registry
│   ├── blazepose.py             # BlazePose adapter
│   ├── movinet_a0.py            # MoViNet-A0 adapter
│   ├── tsm_mobilenetv2.py       # TSM-MobileNetV2 adapter
│   └── vitpose.py               # ViTPose adapter
├── scripts/
│   └── check_environment.py    # Check key runtime dependencies
├── requirements.txt
└── results/                    # Created at runtime for CSV/JSON output
```

## Setup

Python 3.12 is the recommended environment for the current project setup. Create a virtual environment before installing dependencies.

### Linux / Reachy Mini environment

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts/check_environment.py
```

The requirements include the Reachy Mini SDK with its MuJoCo extra, OpenCV, MediaPipe, PyTorch-related model dependencies, Transformers and utility libraries. If installing on the laptop for CUDA testing, install a PyTorch build compatible with the installed NVIDIA driver and CUDA runtime. Verify CUDA before benchmarking:

```bash
python -c "import torch; print('PyTorch:', torch.__version__); print('CUDA available:', torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'No CUDA device detected')"
```

### Windows setup scripts

The repository also contains Windows PowerShell setup scripts:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\setup_cpu.ps1
```

For an NVIDIA GPU, use the GPU setup script instead:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\setup_gpu.ps1
```

Do not reuse the same virtual environment after switching between CPU and GPU setup; recreate `.venv` if changing setup modes.

## How to run the benchmarks

Run commands from the repository root with the virtual environment activated.

### 1. Offline benchmark using a fixed video

This mode is intended for controlled comparisons. It records a 10-second video through the Reachy Mini simulator and then runs each model on the same video file. The video is decoded outside the timed model-inference call.

Start the simulator in a separate terminal:

```bash
reachy-mini-daemon --sim --scene minimal
```

Record the benchmark clip:

```bash
python main.py --record
```

By default, the video is saved to `videos/benchmark_video.mp4`. Keep this file unchanged when comparing models or devices.

Run all models on CPU:

```bash
python main.py --benchmark --device cpu
```

Run the supported PyTorch models on CUDA:

```bash
python main.py --benchmark --device cuda
```

Run a single model:

```bash
python main.py --benchmark --device cpu --models blazepose
python main.py --benchmark --device cuda --models movinet
python main.py --benchmark --device cuda --models tsm
python main.py --benchmark --device cuda --models vitpose
```

Accepted model names are `blazepose`, `movinet`, `tsm`, and `vitpose`, or `all`. BlazePose remains CPU-only in this implementation even when `--device cuda` is selected.

### 2. Live benchmark on the laptop camera

This mode measures live camera processing on the development computer. The laptop GPU test in the results above used an NVIDIA GTX 1650.

```bash
python laptop_camera_benchmark.py --device cuda
```

For CPU testing:

```bash
python laptop_camera_benchmark.py --device cpu
```

Useful options:

```bash
python laptop_camera_benchmark.py --help
python laptop_camera_benchmark.py --device cuda --duration 30 --camera 0
python laptop_camera_benchmark.py --device cuda --width 1920 --height 1080 --camera 0
python laptop_camera_benchmark.py --device cuda --models blazepose,movinet
```

`--camera` selects the camera index; `--width` and `--height` request a camera resolution; `--duration` sets the test duration per model; and `--models` selects the models to run. Actual camera resolution may depend on the camera and backend.

### 3. Live benchmark on Reachy Mini

Run this script on the Reachy Mini itself so inference uses the robot's onboard CPU:

```bash
python reachy_camera_benchmark.py
```

The script starts a live annotated feed and prints a URL that can be opened in a browser. By default, it uses port `8765`; the port can be changed with `--port`.

```bash
python reachy_camera_benchmark.py --help
python reachy_camera_benchmark.py --duration 30
python reachy_camera_benchmark.py --models blazepose,movinet
```

Run only one instance of the benchmark at a time. Close other CPU-heavy processes where possible to reduce measurement noise.

## Metrics and interpretation

The benchmark scripts can report the following, depending on the mode and model:

- **Average latency (ms):** mean duration of an inference call.
- **P50 / P95 / P99 latency (ms):** latency percentiles; P95 means 95% of measured calls completed at or below that value.
- **Output FPS:** successful model outputs per second. This is not necessarily the same as the camera capture rate or display refresh rate.
- **Camera FPS:** observed camera frame throughput in the Reachy Mini live benchmark.
- **Model load time:** time spent loading/initializing the model.
- **CPU use and RAM delta:** process-level measurements during the run.
- **Model metadata:** parameter count and memory information when available.
- **CUDA memory:** allocated GPU memory for supported CUDA runs.
- **Status and errors:** whether the run completed and whether inference errors occurred.

Latency and FPS are related but not exact reciprocals in every live benchmark because of buffering, scheduling, measurement windows and differences in how frames/windows are processed. TSM, for example, uses a sliding window of eight frames.

For a fair comparison:
1. Use the same source video for offline model comparisons.
2. Keep camera resolution and benchmark options fixed when comparing live runs.
3. Allow models to warm up before measuring.
4. Run each test more than once if small differences matter.
5. Compare both average and tail latency (such as P95), not only average FPS.
6. Treat laptop and robot results as separate hardware scenarios.

## Output files

Results are written to a `results/` directory created automatically by the scripts. Timestamped CSV and JSON files are used so runs can be inspected or compared later. Typical names include:

```text
results/benchmark_cpu_<timestamp>.csv
results/benchmark_cpu_<timestamp>.json
results/laptop_camera_<timestamp>.csv
results/laptop_camera_<timestamp>.json
results/reachy_camera_<timestamp>.csv
results/reachy_camera_<timestamp>.json
```

Compare saved offline benchmark JSON files with:

```bash
python compare_results.py results/benchmark_cpu_<timestamp>.json results/benchmark_cuda_<timestamp>.json
```

Replace the example timestamped names with the actual files produced by your runs.

## Current conclusion

The laptop with a GTX 1650 is substantially more capable for these models than the Reachy Mini's onboard CPU. In the current live tests, all four models completed on the laptop at approximately 14–20 output FPS. On the robot, BlazePose was fastest but achieved only about 4 output FPS; the other models were slower still. Therefore, the current results do not support running the heavier models directly on the Reachy Mini CPU when responsive, real-time feedback is required.

A sensible next step is to use the robot for camera capture and movement interaction while performing inference on a more capable computer, or to investigate a smaller/lightweight model and optimized inference path for onboard use. Any final choice should also be evaluated for movement-recognition accuracy on representative, labelled data.

## References

- MediaPipe Pose Landmarker: https://ai.google.dev/edge/api/mediapipe/python/mp/tasks/vision/PoseLandmarker
- ViTPose documentation: https://huggingface.co/docs/transformers/model_doc/vitpose
- MoViNet tutorial: https://www.tensorflow.org/hub/tutorials/movinet
- Temporal Shift Module (TSM): https://github.com/mit-han-lab/temporal-shift-module
- PyTorch installation guide: https://pytorch.org/get-started/locally/

## Scope and limitations

This is an experimental benchmark. It compares computational performance under the tested configurations; it does not compare task-specific accuracy, fairness, robustness, or clinical suitability. Pretrained model outputs may not match the intended movement categories. Hardware, dependencies, drivers, input sizes and model implementations affect the numbers, so rerun the benchmark on the final deployment setup before making deployment decisions.
