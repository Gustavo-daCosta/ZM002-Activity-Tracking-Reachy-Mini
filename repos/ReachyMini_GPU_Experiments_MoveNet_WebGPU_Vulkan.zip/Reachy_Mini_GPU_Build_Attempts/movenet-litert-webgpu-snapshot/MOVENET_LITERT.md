# MoveNet Lightning LiteRT / WebGPU live test

This is an **additive application-layer test** for the supplied ARM64 LiteRT MoveNet Lightning build. Existing benchmark/model files are intentionally untouched.

## Run on Reachy Mini

From the repository root:

```bash
python run_movenet_reachy.py
```

Or for a fixed 30-second test:

```bash
python run_movenet_reachy.py --seconds 30
```

The application:

1. Connects to `ReachyMini(media_backend="webrtc")`.
2. Reads the Reachy camera continuously.
3. Converts the frame to RGB and letterboxes it to 192×192.
4. Writes the uint8 input tensor expected by the supplied model.
5. Executes the supplied ARM64 LiteRT runner with **GPU + WebGPU forced**.
6. Reads the MoveNet `[17, 3]` output.
7. Draws the 17 COCO keypoints and skeleton over the live camera frame.
8. Displays camera FPS, model FPS, average inference latency, P95 latency, inference count and errors directly in the OpenCV window.
9. Prints the final metrics when stopped.

Press **Q** or **Esc** in the camera window to stop.

## Important implementation note

The supplied artifact is a command-line LiteRT runner rather than a Python LiteRT runtime. Therefore this first application layer invokes the runner once per frame. This is useful as a deployment/integration test, but it is **not yet the final high-performance application architecture**. For production, the next step should be a persistent native LiteRT `CompiledModel` instance that stays loaded and reuses the WebGPU compilation/context between frames.

The supplied runner supports GPU/WebGPU flags and `.raw` tensor input. See the LiteRT `run_model` documentation for the corresponding CLI model/input behavior. 
