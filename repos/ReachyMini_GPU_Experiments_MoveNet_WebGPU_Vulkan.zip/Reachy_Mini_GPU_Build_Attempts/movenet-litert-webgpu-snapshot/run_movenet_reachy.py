from __future__ import annotations

import argparse
import statistics
import sys
import time
from collections import deque

import cv2
import numpy as np

from models.movenet_litert.live import MoveNetLiteRT


# COCO keypoint names: nose, eyes, ears, shoulders, elbows, wrists,
# hips, knees, ankles.
KEYPOINT_NAMES = [
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
    "left_wrist", "right_wrist", "left_hip", "right_hip",
    "left_knee", "right_knee", "left_ankle", "right_ankle",
]

CONNECTIONS = [
    (0, 1), (0, 2), (1, 3), (2, 4),
    (5, 6), (5, 7), (7, 9), (6, 8), (8, 10),
    (5, 11), (6, 12), (11, 12),
    (11, 13), (13, 15), (12, 14), (14, 16),
]


class Metrics:
    def __init__(self):
        self.started = time.perf_counter()
        self.camera_frames = 0
        self.inferences = 0
        self.errors = 0
        self.latencies = deque(maxlen=300)
        self.recent_inference_times = deque(maxlen=120)
        self.recent_camera_times = deque(maxlen=120)

    def camera_tick(self, now):
        self.camera_frames += 1
        self.recent_camera_times.append(now)

    def inference_done(self, started, ended):
        self.inferences += 1
        self.latencies.append((ended - started) * 1000.0)
        self.recent_inference_times.append(ended)

    @staticmethod
    def rate(times):
        if len(times) < 2:
            return 0.0
        duration = times[-1] - times[0]
        return (len(times) - 1) / duration if duration > 0 else 0.0

    def camera_fps(self):
        return self.rate(self.recent_camera_times)

    def inference_fps(self):
        return self.rate(self.recent_inference_times)

    def elapsed(self):
        return time.perf_counter() - self.started

    def avg_ms(self):
        return statistics.mean(self.latencies) if self.latencies else 0.0

    def p95_ms(self):
        if not self.latencies:
            return 0.0
        return float(np.percentile(np.asarray(self.latencies), 95))


def draw_pose(frame, keypoints, threshold):
    h, w = frame.shape[:2]
    points = []

    for y, x, score in keypoints:
        px = int(x * w)
        py = int(y * h)
        points.append((px, py, float(score)))

        if score >= threshold and 0 <= px < w and 0 <= py < h:
            cv2.circle(frame, (px, py), 5, (0, 255, 0), -1, cv2.LINE_AA)
            cv2.circle(frame, (px, py), 7, (255, 255, 255), 1, cv2.LINE_AA)

    for a, b in CONNECTIONS:
        ax, ay, ascore = points[a]
        bx, by, bscore = points[b]
        if ascore >= threshold and bscore >= threshold:
            cv2.line(frame, (ax, ay), (bx, by), (0, 255, 0), 3, cv2.LINE_AA)


def draw_metrics(frame, metrics, last_error=None):
    lines = [
        "MoveNet Lightning INT8 | LiteRT GPU / WebGPU",
        f"Camera FPS : {metrics.camera_fps():6.1f}",
        f"Model FPS  : {metrics.inference_fps():6.1f}",
        f"Inference  : {metrics.avg_ms():6.1f} ms avg",
        f"P95        : {metrics.p95_ms():6.1f} ms",
        f"Inferences : {metrics.inferences}",
        f"Errors     : {metrics.errors}",
    ]
    if last_error:
        lines.append(f"ERROR: {last_error[:80]}")

    x, y = 15, 28
    for line in lines:
        cv2.putText(
            frame, line, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
            0.62, (0, 255, 0), 2, cv2.LINE_AA,
        )
        y += 27


def parse_args():
    parser = argparse.ArgumentParser(
        description="Live MoveNet Lightning LiteRT/WebGPU test on Reachy Mini."
    )
    parser.add_argument("--seconds", type=float, default=0.0,
                        help="Stop after N seconds. 0 means run until Q/Esc.")
    parser.add_argument("--threshold", type=float, default=0.30,
                        help="Minimum keypoint confidence to draw.")
    parser.add_argument("--window", default="MoveNet Lightning - Reachy Mini")
    return parser.parse_args()


def main():
    args = parse_args()

    try:
        from reachy_mini import ReachyMini
    except ImportError as exc:
        raise SystemExit("reachy_mini is not installed on this environment.") from exc

    print("=" * 80)
    print("MOVENET LIGHTNING — REACHY MINI LIVE TEST")
    print("=" * 80)
    print("Backend : LiteRT")
    print("GPU     : WebGPU")
    print("Model   : MoveNet Lightning INT8")
    print("Window  : OpenCV")
    print()

    model = None
    mini = None
    metrics = Metrics()
    last_error = None

    try:
        print("Loading LiteRT WebGPU accelerator...")
        model = MoveNetLiteRT()
        print("WebGPU accelerator registered.")
        print("Connecting to Reachy Mini...")
        mini = ReachyMini(media_backend="webrtc")
        print("Camera connected.")
        print("Press Q or ESC in the camera window to stop.")
        print()

        cv2.namedWindow(args.window, cv2.WINDOW_NORMAL)
        started = time.perf_counter()

        while True:
            frame = mini.media.get_frame()
            if frame is None:
                continue

            now = time.perf_counter()
            metrics.camera_tick(now)

            try:
                t0 = time.perf_counter()
                keypoints = model.infer(frame)
                t1 = time.perf_counter()
                metrics.inference_done(t0, t1)
                last_error = None
                draw_pose(frame, keypoints, args.threshold)
            except Exception as exc:
                metrics.errors += 1
                last_error = f"{type(exc).__name__}: {exc}"

            draw_metrics(frame, metrics, last_error)
            cv2.imshow(args.window, frame)

            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
            if args.seconds > 0 and time.perf_counter() - started >= args.seconds:
                break

    finally:
        cv2.destroyAllWindows()
        if model is not None:
            model.close()
        if mini is not None:
            try:
                mini.disconnect()
            except Exception:
                pass

    print()
    print("=" * 80)
    print("FINAL METRICS")
    print("=" * 80)
    print(f"Runtime          : {metrics.elapsed():.2f} s")
    print(f"Camera frames    : {metrics.camera_frames}")
    print(f"Completed runs   : {metrics.inferences}")
    print(f"Errors           : {metrics.errors}")
    print(f"Camera FPS       : {metrics.camera_fps():.2f}")
    print(f"Model FPS        : {metrics.inference_fps():.2f}")
    print(f"Average latency  : {metrics.avg_ms():.2f} ms")
    print(f"P95 latency      : {metrics.p95_ms():.2f} ms")
    print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
