from __future__ import annotations

import os
import re
import subprocess
import tempfile
import time
from collections import deque
from pathlib import Path

import cv2
import numpy as np


MODEL_DIR = Path(__file__).resolve().parent
MODEL_PATH = MODEL_DIR / "movenet-lightning-int8.tflite"
RUNNER = MODEL_DIR / "litert_source_build_cc_api_run_model"
LIB_DIR = MODEL_DIR
INPUT_NAME = "serving_default_input:0"

# MoveNet / COCO 17-keypoint skeleton.
POSE_CONNECTIONS = [
    (0, 1), (0, 2), (1, 3), (2, 4),
    (5, 6), (5, 7), (7, 9), (6, 8), (8, 10),
    (5, 11), (6, 12), (11, 12),
    (11, 13), (13, 15), (12, 14), (14, 16),
]


_FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")


class MoveNetLiteRT:
    """Application-layer adapter around the supplied ARM64 LiteRT runner.

    The runner is intentionally kept as the only native dependency here. It
    loads the TFLite model once per inference process and forces GPU/WebGPU.
    """

    def __init__(self, timeout_s: float = 10.0):
        self.timeout_s = timeout_s
        self._tmp = None
        self._input_dir = None

        if not MODEL_PATH.exists():
            raise FileNotFoundError(f"MoveNet model not found: {MODEL_PATH}")
        if not RUNNER.exists():
            raise FileNotFoundError(f"LiteRT runner not found: {RUNNER}")

        self._tmp = tempfile.TemporaryDirectory(prefix="movenet_litert_")
        self._input_dir = Path(self._tmp.name) / "input"
        self._input_dir.mkdir()

        self._check_accelerator()

    def _env(self):
        env = os.environ.copy()
        existing = env.get("LD_LIBRARY_PATH", "")
        env["LD_LIBRARY_PATH"] = f"{LIB_DIR}:{existing}" if existing else str(LIB_DIR)
        return env

    def _base_command(self):
        return [
            str(RUNNER),
            f"--model={MODEL_PATH}",
            "--accelerator=gpu",
            "--gpu_backend=webgpu",
            "--require_registered_accelerator=gpu",
            f"--runtime_library_dir={LIB_DIR}",
            f"--input_dir={self._input_dir}",
            "--iterations=1",
            "--print_tensors=true",
            "--sample_size=128",
        ]

    def _check_accelerator(self):
        result = subprocess.run(
            [
                str(RUNNER),
                "--registration_only=true",
                "--auto_register_accelerators=gpu",
                "--require_registered_accelerator=gpu",
                f"--runtime_library_dir={LIB_DIR}",
            ],
            env=self._env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=self.timeout_s,
        )
        if result.returncode != 0:
            raise RuntimeError(
                "LiteRT WebGPU accelerator could not be registered.\n\n"
                + result.stdout[-5000:]
            )

    @staticmethod
    def preprocess(frame: np.ndarray) -> np.ndarray:
        """Resize a camera frame to MoveNet's 192x192 RGB uint8 tensor."""
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        scale = min(192.0 / w, 192.0 / h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        resized = cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_LINEAR)
        canvas = np.zeros((192, 192, 3), dtype=np.uint8)
        x = (192 - nw) // 2
        y = (192 - nh) // 2
        canvas[y:y + nh, x:x + nw] = resized
        return canvas[None, ...]

    def infer(self, frame: np.ndarray) -> np.ndarray:
        tensor = self.preprocess(frame)
        (self._input_dir / INPUT_NAME).write_bytes(tensor.tobytes())

        result = subprocess.run(
            self._base_command(),
            env=self._env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=self.timeout_s,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stdout[-6000:])

        values = self._parse_output(result.stdout)
        if values.size < 51:
            raise RuntimeError(
                "LiteRT returned fewer than 51 output values for MoveNet.\n"
                + result.stdout[-6000:]
            )

        return values[:51].reshape(17, 3)

    @staticmethod
    def _parse_output(text: str) -> np.ndarray:
        """Extract the indexed tensor samples printed by run_model."""
        # run_model prints samples as:
        #   Beginning 51 elements:
        #       0: 0.123
        #       1: 0.456
        # With sample_size >= 51 this gives every MoveNet output value.
        values = {}
        in_output = False
        for line in text.splitlines():
            low = line.lower()
            if "output buffer 0" in low:
                in_output = True
                continue
            if not in_output:
                continue

            match = re.match(
                r"\s*(\d+)\s*:\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)\s*$",
                line,
            )
            if match:
                index = int(match.group(1))
                if index not in values:
                    values[index] = float(match.group(2))

        if not values:
            raise RuntimeError(
                "Could not parse MoveNet output tensor from LiteRT runner output.\n"
                + text[-6000:]
            )

        return np.asarray(
            [values[i] for i in sorted(values)],
            dtype=np.float32,
        )

    def close(self):
        if self._tmp is not None:
            self._tmp.cleanup()
            self._tmp = None
