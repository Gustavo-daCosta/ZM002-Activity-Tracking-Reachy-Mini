from .live import MoveNetLiteRT

__all__ = ["MoveNetLiteRT"]
