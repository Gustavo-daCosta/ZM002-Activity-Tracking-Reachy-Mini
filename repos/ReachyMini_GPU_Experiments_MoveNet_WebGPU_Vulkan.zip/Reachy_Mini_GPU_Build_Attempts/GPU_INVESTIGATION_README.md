# Reachy Mini GPU build investigation bundle

This archive groups the final source and binary artifacts from the GPU experiments described in `Reachy_Mini_GPU_Traject_Documentatie.docx`. It preserves the actual build artifacts that were available in the conversation.

## Status at the end of the recorded tests

**No GPU inference pipeline was verified as working end-to-end on the Reachy Mini.** The native BlazePose wrapper and GPU inspector compiled for ARM64, but on the Reachy the inspector crashed while loading the LiteRT WebGPU accelerator with an AES-instruction fatal error. The model inference stage was not reached.

## Contents

- `blazepose-reachy-gpu-fixed/`: the final integrated BlazePose GPU experiment, including `gpu/blazepose_gpu.cpp`, `gpu/inspect_blazepose.cpp`, CMake/build script, extracted BlazePose model files, and the ARM64 build outputs (`libblazepose_gpu.so`, `blazepose_gpu_inspector`).
- `movenet-litert-webgpu-snapshot/`: the MoveNet Lightning LiteRT/WebGPU application-layer snapshot, runner, model, LiteRT runtime and WebGPU accelerator library that hit the same AES incompatibility.
- `alternatives_not_validated/reachy_vulkan_suite/`: a separate NCNN/Vulkan alternative explored but not validated.

## Final compiled BlazePose code

The source that built is `blazepose-reachy-gpu-fixed/gpu/blazepose_gpu.cpp`. A compile-time construction bug was fixed by calling the `BlazePoseGpu` constructor directly:

```cpp
auto* state = new BlazePoseGpu(
    std::move(env),
    std::move(*detector_result),
    std::move(*landmark_result));
```

The build script is `blazepose-reachy-gpu-fixed/gpu/build_arm64.sh`. It expects an existing LiteRT checkout/build under `~/LiteRT` and `~/LiteRT/build-movenet-gpu`; the archive does not contain the full LiteRT source/build tree, only the project and deployed libraries.

## Known problematic binary

`blazepose-reachy-gpu-fixed/gpu/libs/libLiteRtWebGpuAccelerator.so` has SHA-256:

`5f271fa4a36f9dd8d1f8514971b2e80f46bd92b1066509cdd9c0716723d6091a`

The Reachy CM4 CPU did not advertise `aes` or `pmull` in `/proc/cpuinfo`; `objdump` showed AES instructions in this `.so`, and direct `ctypes.CDLL()` loading immediately produced the same fatal error. This copy is included to preserve the exact failing build state for analysis; it is **not represented as a working Reachy-compatible accelerator**.

## Runtime test recorded on Reachy

```bash
cd ~/blazepose-reachy-gpu-fixed/gpu
LD_LIBRARY_PATH="$PWD/libs" \
  ./bin/blazepose_gpu_inspector \
  pose_detector.tflite \
  pose_landmarks_detector.tflite
```

Observed result: LiteRT attempted to load `libLiteRtGpuAccelerator.so` and `libLiteRtWebGpuAccelerator.so`, then terminated with `FATAL ERROR: This binary was compiled with aes enabled, but this feature is not available on this processor` and `Illegal instruction`.

## Important distinction

A successful ARM64 compile of the C++ wrapper is not proof of working GPU inference. The failing component was the separately packaged LiteRT WebGPU accelerator binary, loaded during LiteRT environment setup.
