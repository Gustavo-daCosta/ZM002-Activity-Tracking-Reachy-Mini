from pathlib import Path
import cv2, numpy as np
from vulkan_common import run_benchmark, make_net
import ncnn

ROOT=Path(__file__).resolve().parent
PARAM=ROOT/"weights/vulkan/movinet_a0.ncnn.param"
BIN=ROOT/"weights/vulkan/movinet_a0.ncnn.bin"

def preprocess(frame):
    x=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); x=cv2.resize(x,(172,172),interpolation=cv2.INTER_AREA)
    x=x.astype(np.float32)/255.0
    return x.transpose(2,0,1)

def annotate(frame,out): pass

def main():
    if not PARAM.exists() or not BIN.exists():
        raise SystemExit("Missing Vulkan model. Prepare it first; see prepare_vulkan_models.py.")
    dev=__import__("vulkan_common").check_vulkan(ncnn)
    net=make_net(ncnn,PARAM,BIN,dev)
    run_benchmark("MoViNet-A0",net,preprocess,annotate,15,8765)
if __name__=="__main__": main()
