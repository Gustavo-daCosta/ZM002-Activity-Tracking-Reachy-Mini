from pathlib import Path
import cv2, numpy as np, ncnn
from vulkan_common import run_benchmark, make_net

ROOT=Path(__file__).resolve().parent; PARAM=ROOT/"weights/vulkan/tsm_mobilenetv2.ncnn.param"; BIN=ROOT/"weights/vulkan/tsm_mobilenetv2.ncnn.bin"
buf=[]
def preprocess(frame):
    rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); rgb=cv2.resize(rgb,(224,224),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255.0
    mean=np.array([.485,.456,.406],np.float32); std=np.array([.229,.224,.225],np.float32)
    return ((rgb-mean)/std).transpose(2,0,1)
def annotate(frame,out): pass
def main():
    global buf
    if not PARAM.exists() or not BIN.exists(): raise SystemExit("Missing Vulkan model. Prepare it first; see prepare_vulkan_models.py.")
    dev=__import__("vulkan_common").check_vulkan(ncnn); net=make_net(ncnn,PARAM,BIN,dev)
    # This standalone benchmark uses one 8-frame clip per inference. Camera frames are collected by a custom loop.
    # For an exact TSM comparison, use the same rolling 8-frame buffer as the CPU adapter.
    import time, socket, psutil, statistics, json, csv
    from datetime import datetime
    from vulkan_common import Live,start_server,reachy
    mini=reachy(); feed=Live(); server=start_server(feed,8765); proc=psutil.Process(); frames=[]; lats=[]; start=time.perf_counter(); seen=done=errors=0
    while time.perf_counter()-start<15:
        f=mini.media.get_frame()
        if f is None: continue
        f=f.copy(); seen+=1; frames.append(f)
        if len(frames)>8: frames.pop(0)
        if len(frames)<8: continue
        try:
            clip=np.stack([preprocess(x) for x in frames],axis=0)
            # ncnn accepts 4D/5D tensors depending on build; this is a 5D batch clip.
            t=time.perf_counter(); ex=net.create_extractor(); ex.input("in0",ncnn.Mat(clip)); ret,out=ex.extract("out0"); dt=(time.perf_counter()-t)*1000
            if ret!=0: raise RuntimeError(ret)
            lats.append(dt); done+=1
        except Exception as e:
            errors+=1
            if errors<=3: print("Frame error:",e)
        fps=done/max(time.perf_counter()-start,.001)
        cv2.putText(f,"Model: TSM-MobileNetV2",(15,30),0,.65,(0,255,0),2); cv2.putText(f,"Device: Vulkan / ncnn",(15,60),0,.65,(0,255,0),2); cv2.putText(f,f"Model FPS: {fps:.2f}",(15,90),0,.65,(0,255,0),2); feed.set(f)
    feed.running=False; server.shutdown(); mini.close()
    ts=datetime.now().strftime("%Y%m%d_%H%M%S"); Path("results").mkdir(exist_ok=True)
    row={"timestamp":ts,"model":"TSM-MobileNetV2","implementation":"ncnn Vulkan","avg_ms":statistics.mean(lats) if lats else 0,"p95_ms":float(np.percentile(lats,95)) if lats else 0,"fps":done/15,"frames_seen":seen,"completed":done,"errors":errors,"device":"Vulkan"}
    with open(f"results/vulkan_tsm_{ts}.csv","w",newline="") as fp: csv.DictWriter(fp,fieldnames=row).writeheader(); csv.DictWriter(fp,fieldnames=row).writerow(row)
    print(json.dumps(row,indent=2))
if __name__=="__main__": main()
