"""
BlazePose Vulkan status/runner.

MediaPipe's Python Pose Landmarker does not expose a Vulkan compute backend on
Linux/Reachy. Therefore this script NEVER pretends to run BlazePose on Vulkan.
It verifies Vulkan and exits with a clear message instead of silently using CPU.
"""
import ncnn
from vulkan_common import check_vulkan
def main():
    check_vulkan(ncnn)
    raise SystemExit(
        "BlazePose: no supported Vulkan implementation is available in the "
        "current MediaPipe Tasks Python API on Reachy. This script intentionally "
        "refuses CPU fallback. Use the CPU benchmark or provide a converted "
        "BlazePose model/backend."
    )
if __name__=="__main__": main()
