"""
prepare_vulkan_models.py

This prepares PyTorch models for ncnn/Vulkan. It does NOT run inference.
MoViNet and TSM are attempted automatically. ViTPose is attempted with a
fixed 256x192 tensor. BlazePose is intentionally not converted here because
the MediaPipe .task container is not a PyTorch/ONNX model.
"""
from pathlib import Path
import sys, traceback
ROOT=Path(__file__).resolve().parent
OUT=ROOT/"weights/vulkan"; OUT.mkdir(parents=True,exist_ok=True)

def movinet():
    import torch, pnnx
    from movinets import MoViNet
    from movinets.config import _C
    m=MoViNet(_C.MODEL.MoViNetA0,causal=True,pretrained=True).eval()
    x=torch.zeros(1,3,1,172,172)
    pnnx.export(m,str(OUT/"movinet_a0.pt"),(x,))
def tsm():
    import torch, pnnx
    sys.path.insert(0,str(ROOT/"external/temporal-shift-module"))
    from ops.models import TSN
    m=TSN(400,8,"RGB",base_model="mobilenetv2",consensus_type="avg",before_softmax=True,dropout=.8,img_feature_dim=256,crop_num=1,partial_bn=True,pretrain="imagenet",is_shift=True,shift_div=8,shift_place="blockres",fc_lr5=False,temporal_pool=False,non_local=False).eval()
    ck=ROOT/"weights/TSM_kinetics_RGB_mobilenetv2_shift8_blockres_avg_segment8_e100_dense.pth"
    if ck.exists():
        sd=torch.load(ck,map_location="cpu"); sd=sd.get("state_dict",sd); sd={k.removeprefix("module."):v for k,v in sd.items()}
        if "base_model.classifier.weight" in sd: sd["new_fc.weight"]=sd.pop("base_model.classifier.weight")
        if "base_model.classifier.bias" in sd: sd["new_fc.bias"]=sd.pop("base_model.classifier.bias")
        m.load_state_dict(sd,strict=True)
    x=torch.zeros(1,8,3,224,224)
    pnnx.export(m,str(OUT/"tsm_mobilenetv2.pt"),(x,))
def vitpose():
    import torch,pnnx
    from transformers import VitPoseForPoseEstimation
    m=VitPoseForPoseEstimation.from_pretrained("usyd-community/vitpose-base-simple").eval()
    class Wrap(torch.nn.Module):
        def __init__(self,model): super().__init__(); self.model=model
        def forward(self,x): return self.model(pixel_values=x).heatmaps
    w=Wrap(m).eval(); x=torch.zeros(1,3,256,192)
    pnnx.export(w,str(OUT/"vitpose.pt"),(x,))
for name,fn in [("MoViNet",movinet),("TSM",tsm),("ViTPose",vitpose)]:
    print("\n==",name,"==")
    try: fn(); print("OK")
    except Exception as e: print("FAILED:",e); traceback.print_exc()
print("\nRun pnnx-generated .ncnn files should be placed in weights/vulkan/ with the names expected by the runner.")
