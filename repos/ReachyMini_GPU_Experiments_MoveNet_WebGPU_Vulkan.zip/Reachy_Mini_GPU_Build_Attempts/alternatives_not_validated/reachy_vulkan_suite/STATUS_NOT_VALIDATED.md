# Status: not validated

These files are the NCNN/Vulkan alternative scripts included for historical completeness. In the conversation they were not built or run successfully on the Reachy Mini. Do not treat them as a working Vulkan build.
