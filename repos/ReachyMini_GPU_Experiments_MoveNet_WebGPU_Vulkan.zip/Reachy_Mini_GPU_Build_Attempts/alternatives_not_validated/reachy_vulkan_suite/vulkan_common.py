from __future__ import annotations
import argparse, csv, json, os, socket, statistics, threading, time
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import cv2, numpy as np, psutil

@dataclass
class Bench:
    name: str
    implementation: str
    latencies: list
    frames: int = 0
    completed: int = 0
    errors: int = 0
    load_ms: float = 0.0
    ram_after_load: float = 0.0
    peak_ram_delta: float = 0.0
    params: int | None = None
    model_mb: float | None = None

class Live:
    def __init__(self): self.lock=threading.Lock(); self.jpeg=None; self.running=True
    def set(self, frame):
        ok, enc=cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY,80])
        if ok:
            with self.lock: self.jpeg=enc.tobytes()
    def get(self):
        with self.lock: return self.jpeg

class Handler(BaseHTTPRequestHandler):
    store=None
    def log_message(self,*a): pass
    def do_GET(self):
        if self.path=="/":
            d=b'<!doctype html><html><body style="margin:0;background:#111;text-align:center"><h2 style="color:white">Reachy Mini Vulkan benchmark</h2><img src="/stream" style="max-width:96vw;max-height:90vh"></body></html>'
            self.send_response(200); self.send_header("Content-Type","text/html"); self.send_header("Content-Length",str(len(d))); self.end_headers(); self.wfile.write(d); return
        if self.path!="/stream": self.send_error(404); return
        self.send_response(200); self.send_header("Content-Type","multipart/x-mixed-replace; boundary=frame"); self.send_header("Cache-Control","no-cache"); self.end_headers()
        last=None
        try:
            while self.store.running:
                j=self.store.get()
                if j is None or j==last: time.sleep(.02); continue
                last=j; self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "+str(len(j)).encode()+b"\r\n\r\n"+j+b"\r\n"); self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError): pass

def start_server(store, port):
    Handler.store=store; s=ThreadingHTTPServer(("0.0.0.0",port),Handler); threading.Thread(target=s.serve_forever,daemon=True).start(); return s

def reachy():
    from reachy_mini import ReachyMini
    return ReachyMini()

def check_vulkan(ncnn):
    try:
        count=ncnn.get_gpu_count()
    except Exception as e:
        raise RuntimeError(f"ncnn Vulkan build/driver unavailable: {e}")
    if count < 1:
        raise RuntimeError("ncnn reports 0 Vulkan GPU devices. Refusing CPU fallback.")
    dev=ncnn.get_gpu_device(ncnn.get_default_gpu_index())
    print(f"Vulkan GPU: {dev}")
    return dev

def make_net(ncnn, param, model, dev):
    net=ncnn.Net()
    net.opt.use_vulkan_compute=True
    net.opt.use_fp16_packed=True
    net.opt.use_fp16_storage=True
    net.opt.use_fp16_arithmetic=True
    net.opt.use_packing_layout=True
    net.set_vulkan_device(dev)
    if net.load_param(str(param)) != 0: raise RuntimeError(f"Failed to load {param}")
    if net.load_model(str(model)) != 0: raise RuntimeError(f"Failed to load {model}")
    return net

def run_benchmark(model_name, model, preprocess, annotate, duration, port, model_mb=None, params=None):
    import ncnn
    dev=check_vulkan(ncnn)
    mini=reachy(); feed=Live(); server=start_server(feed,port)
    ip=socket.gethostbyname(socket.gethostname())
    print(f"Live feed: http://reachy-mini.local:{port}/")
    print(f"or: http://{ip}:{port}/")
    proc=psutil.Process(os.getpid())
    load_ram=proc.memory_info().rss/1024**2
    warm=[]
    for i in range(8):
        f=mini.media.get_frame()
        if f is not None: warm.append(f.copy())
    for f in warm:
        x=preprocess(f); ex=model.create_extractor(); ex.input("in0",ncnn.Mat(x)); ex.extract("out0")
    lats=[]; start=time.perf_counter(); seen=0; done=0; errors=0; peak=0
    while time.perf_counter()-start<duration:
        f=mini.media.get_frame()
        if f is None: continue
        f=f.copy(); seen+=1
        try:
            x=preprocess(f)
            t=time.perf_counter()
            ex=model.create_extractor(); ex.input("in0",ncnn.Mat(x)); ret,out=ex.extract("out0")
            dt=(time.perf_counter()-t)*1000
            if ret!=0: raise RuntimeError(f"ncnn extract returned {ret}")
            lats.append(dt); done+=1
            annotate(f,np.asarray(out))
        except Exception as e:
            errors+=1
            if errors<=3: print("Frame error:",e)
        elapsed=time.perf_counter()-start
        fps=done/max(elapsed,.001)
        cv2.putText(f,f"Model: {model_name}",(15,30),0,.65,(0,255,0),2)
        cv2.putText(f,"Device: Vulkan / ncnn",(15,60),0,.65,(0,255,0),2)
        cv2.putText(f,f"Model FPS: {fps:.2f}",(15,90),0,.65,(0,255,0),2)
        cv2.putText(f,f"Inference: {lats[-1]:.1f} ms" if lats else "Inference: -",(15,120),0,.65,(0,255,0),2)
        rss=proc.memory_info().rss/1024**2; peak=max(peak,rss-load_ram); feed.set(f)
    feed.running=False; server.shutdown(); mini.close()
    avg=statistics.mean(lats) if lats else 0; p95=np.percentile(lats,95) if lats else 0
    ts=datetime.now().strftime("%Y%m%d_%H%M%S")
    Path("results").mkdir(exist_ok=True)
    row={"timestamp":ts,"model":model_name,"implementation":"ncnn Vulkan","avg_ms":avg,"p95_ms":float(p95),"fps":done/max(duration,.001),"frames_seen":seen,"completed":done,"errors":errors,"ram_delta_mb":peak,"model_mb":model_mb,"parameters":params,"device":"Vulkan"}
    with open(f"results/vulkan_{model_name.lower().replace('-','_')}_{ts}.json","w") as fp: json.dump(row,fp,indent=2)
    with open(f"results/vulkan_{ts}.csv","w",newline="") as fp:
        w=csv.DictWriter(fp,fieldnames=row.keys()); w.writeheader(); w.writerow(row)
    print("\nRESULT"); print(json.dumps(row,indent=2))
