from pathlib import Path
import cv2, numpy as np, ncnn
from vulkan_common import run_benchmark, make_net
ROOT=Path(__file__).resolve().parent; PARAM=ROOT/"weights/vulkan/vitpose.ncnn.param"; BIN=ROOT/"weights/vulkan/vitpose.ncnn.bin"
def preprocess(frame):
    # Fixed 256x192 input. The exported wrapper must use this exact shape.
    rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); rgb=cv2.resize(rgb,(192,256),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255.0
    mean=np.array([.485,.456,.406],np.float32); std=np.array([.229,.224,.225],np.float32)
    return ((rgb-mean)/std).transpose(2,0,1)
def annotate(frame,out): pass
def main():
    if not PARAM.exists() or not BIN.exists(): raise SystemExit("Missing Vulkan model. Prepare it first; see prepare_vulkan_models.py.")
    dev=__import__("vulkan_common").check_vulkan(ncnn); net=make_net(ncnn,PARAM,BIN,dev)
    run_benchmark("ViTPose",net,preprocess,annotate,15,8765)
if __name__=="__main__": main()
