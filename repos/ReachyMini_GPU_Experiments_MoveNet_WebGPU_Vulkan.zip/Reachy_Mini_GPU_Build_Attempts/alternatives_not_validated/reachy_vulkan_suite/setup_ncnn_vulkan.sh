#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "== Vulkan hardware =="
command -v vulkaninfo >/dev/null 2>&1 && vulkaninfo --summary || true
echo
echo "== Installing build dependencies =="
sudo apt-get update
sudo apt-get install -y build-essential cmake git libprotobuf-dev protobuf-compiler libomp-dev libopencv-dev vulkan-tools libvulkan1 mesa-vulkan-drivers
echo
echo "== Building ncnn with Vulkan + Python =="
if [ ! -d external/ncnn ]; then
  git clone --recursive --depth 1 https://github.com/Tencent/ncnn.git external/ncnn
fi
cmake -S external/ncnn -B external/ncnn/build \
  -DCMAKE_BUILD_TYPE=Release \
  -DNCNN_VULKAN=ON \
  -DNCNN_BUILD_EXAMPLES=OFF \
  -DNCNN_BUILD_TOOLS=ON \
  -DNCNN_PYTHON=ON \
  -DNCNN_BUILD_BENCHMARK=OFF
cmake --build external/ncnn/build -j2
cmake --install external/ncnn/build --prefix "$HOME/.local"
export LD_LIBRARY_PATH="$HOME/.local/lib:${LD_LIBRARY_PATH:-}"
python -m pip install --no-cache-dir pnnx
python - <<'PY'
import ncnn
print("ncnn:", ncnn)
print("Vulkan devices:", ncnn.get_gpu_count())
for i in range(ncnn.get_gpu_count()):
    print(i, ncnn.get_gpu_device(i))
PY
echo
echo "If Vulkan devices > 0, the runtime is ready."
